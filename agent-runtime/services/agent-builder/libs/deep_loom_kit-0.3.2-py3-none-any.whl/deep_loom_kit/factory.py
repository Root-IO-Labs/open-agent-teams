"""Config → create_deep_agent() wiring."""

from __future__ import annotations

import asyncio
import importlib
import json as _json
import os
import re
import shutil
import warnings
from contextlib import AsyncExitStack
from pathlib import Path
from typing import Annotated, Any

from deepagents import SubAgent, create_deep_agent
from langchain_core.runnables import RunnableConfig
from langchain_core.tools import InjectedToolArg, StructuredTool
from langgraph.checkpoint.memory import InMemorySaver
from pydantic import BaseModel as _MCPArgsBase

from .backends import build_backend, build_skills_backend_factory, build_store
from .middleware import DatetimeMiddleware
from .runtime import AgentRuntime
from .schema import AgentConfig, MCPServerInfo, MCPToolInfo, ServiceConfig
from .tools import resolve_tools


def _qualify_model(model: str) -> str:
    """Return model string with provider prefix. Defaults to ``anthropic:`` if no prefix given.

    Examples:
        "claude-sonnet-4-6"        → "anthropic:claude-sonnet-4-6"
        "anthropic:claude-opus-4"  → "anthropic:claude-opus-4"   (unchanged)
        "openai:gpt-4o"            → "openai:gpt-4o"             (unchanged)
        "moonshot:moonshot-v1-8k"  → "moonshot:moonshot-v1-8k"   (unchanged)
    """
    if ":" not in model:
        return f"anthropic:{model}"
    return model


def _import_context_schema(dotted_path: str) -> type | None:
    """Import a dataclass from a dotted module path, e.g. ``"myapp.contexts.UserContext"``.

    Returns the class on success, or ``None`` (with a warning) if the import fails.
    """
    try:
        module_path, class_name = dotted_path.rsplit(".", 1)
        module = importlib.import_module(module_path)
        return getattr(module, class_name)
    except (ImportError, AttributeError, ValueError) as exc:
        warnings.warn(
            f"create_runtime: could not import context_schema '{dotted_path}': {exc}. "
            "context_schema will be omitted."
        )
        return None


def _build_middleware_list(config: AgentConfig, context_label: str) -> list[Any]:
    """Build ordered middleware list: DatetimeMiddleware (if enabled) + user-defined middleware.

    Args:
        config: Agent or subagent configuration.
        context_label: Prefix for warning messages (e.g. ``"Subagent 'foo'"``).
    """
    mw: list[Any] = []
    if config.datetime_awareness:
        mw.append(DatetimeMiddleware())
    if config.middleware:
        from .middleware import resolve_middleware
        try:
            mw.extend(resolve_middleware(config.middleware))
        except ValueError as exc:
            warnings.warn(f"{context_label}: {exc}. Middleware will be skipped.")
    return mw


def _build_subagent_dict(sub: AgentConfig) -> SubAgent:
    """Map an :class:`AgentConfig` to a :class:`SubAgent` dict."""
    d: SubAgent = {
        "name": sub.name,
        "description": sub.description or sub.name,
        "system_prompt": sub.effective_prompt or "",
    }
    if sub.effective_model_string:
        d["model"] = sub.effective_model_string
    if sub.tools:
        # Custom subagents do NOT inherit tools from the main agent (per deepagents docs).
        # Warn about any unregistered tools rather than silently dropping them.
        try:
            d["tools"] = resolve_tools(sub.tools)
        except ValueError as exc:
            warnings.warn(f"Subagent '{sub.name}': {exc}. Subagent will have no tools.")
    if sub.skills:
        # Source path is the subagent's skill namespace.  SkillsMiddleware scans this dir
        # and treats each subdir as a skill (each containing SKILL.md).
        # e.g. /skills/planner/ → finds planning/ → reads planning/SKILL.md
        d["skills"] = [f"/skills/{sub.name}/"]
    mw = _build_middleware_list(sub, f"Subagent '{sub.name}'")
    if mw:
        d["middleware"] = mw
    if sub.interrupt_on is not None:
        d["interrupt_on"] = sub.interrupt_on
    return d


def _get_isolation_variable(agent_config: AgentConfig) -> str | None:
    """Extract the context isolation variable name from an agent config.

    Returns the variable name when ``isolation.mode == "context"`` is set on
    either ``composite_backend`` or the standalone ``backend``, or ``None``.
    """
    iso = (
        (agent_config.composite_backend.isolation if agent_config.composite_backend else None)
        or (getattr(agent_config.backend, "isolation", None) if agent_config.backend else None)
    )
    if iso is not None and iso.mode == "context":
        return iso.variable
    return None


_MCP_PLACEHOLDER_RE = re.compile(r"\$\{([^}]+)\}")
_MCP_DYNAMIC_PATTERN = re.compile(r"\$\{(thread_id|context\.)")


def _expand_mcp_template(
    value: str,
    *,
    thread_id: str,
    context: Any,
) -> str:
    """Expand ${env.VAR}, ${thread_id}, ${context.field} placeholders in *value*.

    Raises:
        ValueError: if a referenced ${env.VAR} is not in os.environ, or a
            ${context.field} is missing from the context object.
    """
    def _replace(m: re.Match) -> str:
        key = m.group(1)
        if key.startswith("env."):
            var = key[4:]
            val = os.environ.get(var)
            if val is None:
                raise ValueError(
                    f"MCP template references ${{{key}}} but {var!r} is not set in os.environ."
                )
            return val
        if key == "thread_id":
            return thread_id
        if key.startswith("context."):
            field = key[8:]
            if context is None or not hasattr(context, field):
                raise ValueError(
                    f"MCP template references ${{{key}}} but context has no attribute {field!r}."
                )
            return str(getattr(context, field))
        # Unknown placeholder — leave as-is (forward-compatible)
        return m.group(0)

    return _MCP_PLACEHOLDER_RE.sub(_replace, value)


def _is_static_mcp_config(cfg: Any) -> bool:
    """Return True if *cfg* contains no ${thread_id} or ${context.X} placeholders."""
    def _has_dynamic(val: str) -> bool:
        return bool(_MCP_DYNAMIC_PATTERN.search(val))

    for field_val in cfg.model_dump().values():
        if isinstance(field_val, str) and _has_dynamic(field_val):
            return False
        if isinstance(field_val, list):
            if any(isinstance(v, str) and _has_dynamic(v) for v in field_val):
                return False
        if isinstance(field_val, dict):
            if any(isinstance(v, str) and _has_dynamic(v) for v in field_val.values()):
                return False
    return True


def _partition_mcp_servers(
    servers: list[Any],
) -> tuple[list[Any], list[Any]]:
    """Split MCP server configs into (static, dynamic) lists."""
    static, dynamic = [], []
    for s in servers:
        (static if _is_static_mcp_config(s) else dynamic).append(s)
    return static, dynamic


def _require_mcp_adapters() -> Any:
    """Import MultiServerMCPClient or raise ImportError with install hint."""
    try:
        from langchain_mcp_adapters.client import MultiServerMCPClient  # type: ignore[import]
        return MultiServerMCPClient
    except ImportError as exc:
        raise ImportError(
            "MCP server support requires langchain-mcp-adapters. "
            "Install it with: pip install deep-loom-kit[mcp]"
        ) from exc


def _make_mcp_client(servers: list[Any]) -> Any:
    """Construct a MultiServerMCPClient from a list of resolved server configs."""
    MultiServerMCPClient = _require_mcp_adapters()
    from .schema import HttpMCPServerConfig as _Http, StdioMCPServerConfig as _Stdio
    server_params: dict[str, Any] = {}
    for s in servers:
        if isinstance(s, _Stdio):
            server_params[s.name] = {
                "transport": "stdio",
                "command": s.command,
                "args": s.args,
                "env": s.env or None,
            }
        else:  # HttpMCPServerConfig
            server_params[s.name] = {
                "transport": "streamable_http",
                "url": s.url,
                "headers": s.headers or None,
            }
    return MultiServerMCPClient(server_params)


def _check_stdio_server(server_name: str, command: str) -> None:
    """Raise RuntimeError if *command* is not on PATH."""
    if shutil.which(command) is None:
        raise RuntimeError(
            f"MCP server '{server_name}': command '{command}' not found on PATH. "
            "Install it or check your mcp_servers config."
        )


async def _check_remote_server(server_name: str, url: str) -> None:
    """Raise RuntimeError if *url* is unreachable (lightweight HEAD request, 2 s timeout)."""
    try:
        import httpx
    except ImportError:
        return  # httpx not available; skip check (shouldn't happen with mcp extra)
    try:
        async with httpx.AsyncClient() as client:
            await client.head(url, timeout=2.0)
    except (httpx.TransportError, httpx.InvalidURL, OSError) as exc:
        raise RuntimeError(
            f"MCP server '{server_name}': URL '{url}' is unreachable: {exc}. "
            "Check that the URL is correct and the server is running."
        ) from exc


async def _build_static_mcp_tools(
    static_servers: list[Any],
) -> tuple[dict[str, Any], AsyncExitStack, list[MCPServerInfo]]:
    """Connect static MCP servers with persistent sessions.

    Uses ``client.session()`` + ``AsyncExitStack`` so each stdio server keeps one
    subprocess alive for the runtime's lifetime instead of spawning a new process
    per tool call.  The exit stack must be closed via ``AgentRuntime.aclose()``.

    Raises:
        ValueError: on duplicate server names.
        RuntimeError: if a pre-flight health check fails.
        ImportError: if langchain-mcp-adapters is not installed.
    """
    _require_mcp_adapters()
    from langchain_mcp_adapters.tools import load_mcp_tools

    # Collision detection
    seen: set[str] = set()
    for s in static_servers:
        if s.name in seen:
            raise ValueError(
                f"MCP server name {s.name!r} is used more than once. "
                "Each server must have a unique name."
            )
        seen.add(s.name)

    # Expand ${env.X} placeholders (static servers have no dynamic refs)
    from .schema import HttpMCPServerConfig as _Http, StdioMCPServerConfig as _Stdio
    expanded: list[Any] = []
    for s in static_servers:
        data = s.model_dump()
        for k, v in data.items():
            if isinstance(v, str):
                data[k] = _expand_mcp_template(v, thread_id="", context=None)
            elif isinstance(v, list):
                data[k] = [
                    _expand_mcp_template(x, thread_id="", context=None)
                    if isinstance(x, str) else x
                    for x in v
                ]
            elif isinstance(v, dict):
                data[k] = {
                    dk: _expand_mcp_template(dv, thread_id="", context=None)
                    if isinstance(dv, str) else dv
                    for dk, dv in v.items()
                }
        expanded.append(_Stdio(**data) if isinstance(s, _Stdio) else _Http(**data))

    # Pre-flight health checks — collect all errors before failing
    errors: list[str] = []
    for s in expanded:
        try:
            if isinstance(s, _Stdio):
                _check_stdio_server(s.name, s.command)
            else:
                await _check_remote_server(s.name, s.url)
        except RuntimeError as exc:
            errors.append(str(exc))
    if errors:
        raise RuntimeError(
            "MCP pre-flight health check(s) failed:\n"
            + "\n".join(f"  - {e}" for e in errors)
        )

    # Build persistent sessions via AsyncExitStack
    client = _make_mcp_client(expanded)
    exit_stack = AsyncExitStack()
    tool_map: dict[str, Any] = {}
    server_infos: list[MCPServerInfo] = []

    try:
        for s in expanded:
            session = await exit_stack.enter_async_context(client.session(s.name))
            tools = await load_mcp_tools(session, server_name=s.name)
            tool_infos: list[MCPToolInfo] = []
            for tool in tools:
                tool_name = tool.name.split("__", 1)[1] if "__" in tool.name else tool.name
                ns_key = f"{s.name}/{tool_name}"
                tool_map[ns_key] = tool
                tool_infos.append(MCPToolInfo(name=ns_key, description=tool.description or ""))
            server_infos.append(MCPServerInfo(
                name=s.name,
                transport="stdio" if isinstance(s, _Stdio) else "http",
                tools=tool_infos,
            ))
    except Exception:
        await exit_stack.aclose()
        raise

    return tool_map, exit_stack, server_infos


def _expand_mcp_wildcards(
    mcp_refs: list[str],
    tool_map: dict[str, Any],
) -> list[str]:
    """Expand wildcard refs (``server/*``) using keys in *tool_map*.

    Raises:
        ValueError: if a wildcard ref targets a server with no entries AND
            that server prefix does not appear in any key in *tool_map*.
    """
    result: list[str] = []
    known_servers = {k.split("/")[0] for k in tool_map}
    for ref in mcp_refs:
        if ref.endswith("/*"):
            server = ref[:-2]
            matched = [k for k in tool_map if k.startswith(f"{server}/")]
            if not matched and server not in known_servers:
                raise ValueError(
                    f"MCP wildcard 'mcp:{ref}' references unknown server {server!r}. "
                    "Check mcp_servers: in your agent YAML."
                )
            result.extend(matched)
        else:
            result.append(ref)
    return result


class _ProbeContext:
    """Sentinel context object that returns empty string for any attribute access.

    Used during MCP server probing to silently substitute ${context.X} placeholders.
    """

    def __getattr__(self, name: str) -> str:
        return ""


async def _probe_dynamic_mcp_tools(dynamic_servers: list[Any]) -> dict[str, str]:
    """Connect to all dynamic servers in one client (with empty placeholders) to discover tools.

    Returns a dict of ``namespaced_tool_key → description`` for system prompt injection.
    The connection is closed immediately after probing.

    Raises:
        ValueError: on duplicate server names.
    """
    from .schema import StdioMCPServerConfig as _Stdio, HttpMCPServerConfig as _Http

    _probe_ctx = _ProbeContext()

    # Collision detection
    seen: set[str] = set()
    for server in dynamic_servers:
        if server.name in seen:
            raise ValueError(
                f"MCP server name {server.name!r} is used more than once. "
                "Each server must have a unique name."
            )
        seen.add(server.name)

    # Expand all placeholders with empty-string substitutions for dynamic refs
    expanded: list[Any] = []
    for server in dynamic_servers:
        data = server.model_dump()
        for k, v in data.items():
            if isinstance(v, str):
                data[k] = _expand_mcp_template(v, thread_id="", context=_probe_ctx)
            elif isinstance(v, list):
                data[k] = [
                    _expand_mcp_template(x, thread_id="", context=_probe_ctx)
                    if isinstance(x, str) else x
                    for x in v
                ]
            elif isinstance(v, dict):
                data[k] = {
                    dk: _expand_mcp_template(dv, thread_id="", context=_probe_ctx)
                    if isinstance(dv, str) else dv
                    for dk, dv in v.items()
                }
        expanded.append(_Stdio(**data) if isinstance(server, _Stdio) else _Http(**data))

    # Connect all servers in a single client (mirrors _build_static_mcp_tools)
    client = _make_mcp_client(expanded)
    tools = await client.get_tools()
    descriptions: dict[str, str] = {}
    for tool in tools:
        if "__" in tool.name:
            server_name, tool_name = tool.name.split("__", 1)
        else:
            server_name = expanded[0].name if len(expanded) == 1 else "unknown"
            tool_name = tool.name
        descriptions[f"{server_name}/{tool_name}"] = tool.description or ""

    return descriptions


def _inject_dynamic_mcp_prompt(
    base_prompt: str | None,
    descriptions: dict[str, str],
) -> str | None:
    """Append a dynamic MCP tools block to *base_prompt*.

    Returns *base_prompt* unchanged when *descriptions* is empty.
    """
    if not descriptions:
        return base_prompt

    lines = ["", "## Available MCP tools (dynamic)"]
    for key, desc in descriptions.items():
        lines.append(f"- mcp:{key}: {desc}")
    lines.append("")
    lines.append(
        "To call these tools, use the `_mcp_dynamic_dispatch` tool with `tool_name` "
        "(e.g. \"github/create_pr\" — without the mcp: prefix) and `arguments`."
    )
    block = "\n".join(lines)

    if base_prompt:
        return base_prompt + "\n" + block
    return block.strip()


def _mcp_dynamic_dispatch(
    tool_name: str,
    arguments: dict,
    config: Any,
) -> str:
    """Proxy tool that dispatches calls to dynamic MCP tools at runtime."""
    tool_map: dict = {}
    if isinstance(config, dict):
        tool_map = config.get("configurable", {}).get("mcp_tool_map", {})
    tool = tool_map.get(tool_name)
    if tool is None:
        return f"ERROR: unknown dynamic MCP tool '{tool_name}'"
    result = tool.invoke(arguments)
    return result if isinstance(result, str) else _json.dumps(result)


def _make_mcp_dispatch_tool() -> Any:
    """Wrap _mcp_dynamic_dispatch as a LangChain StructuredTool with InjectedToolArg config."""

    class _MCPDispatchArgs(_MCPArgsBase):
        tool_name: str
        arguments: dict

    def _dispatch(
        tool_name: str,
        arguments: dict,
        config: Annotated[RunnableConfig, InjectedToolArg],
    ) -> str:
        return _mcp_dynamic_dispatch(tool_name, arguments, config)

    return StructuredTool.from_function(
        func=_dispatch,
        name="_mcp_dynamic_dispatch",
        description="Call a dynamic MCP tool by name and arguments.",
        args_schema=_MCPDispatchArgs,
    )


def _resolve_skills_dir(config: ServiceConfig, service_root: Path | None) -> Path | None:
    """Determine the skills directory from service config and root directory."""
    if config.skills_dir and config.root_dir:
        _raw = Path(config.skills_dir)
        return _raw if _raw.is_absolute() else (config.root_dir / _raw).resolve()
    elif config.skills_dir:
        _raw = Path(config.skills_dir)
        return _raw if _raw.is_absolute() else None  # can't resolve relative without root
    else:
        return service_root / "skills" if service_root else None


def _build_subagents_list(config: AgentConfig) -> list[Any]:
    """Merge YAML-resolved subagents with compiled agents into a single list."""
    from .compiled_agents import resolve_compiled_agents

    subagents: list[Any] = [_build_subagent_dict(s) for s in config.resolved_subagents]
    if config.compiledagents:
        try:
            subagents += resolve_compiled_agents(config.compiledagents)
        except ValueError as exc:
            warnings.warn(f"create_runtime: {exc}. Compiled agents will be skipped.")
    return subagents


def _build_create_agent_kwargs(
    config: AgentConfig,
    tools: list[Any],
    backend_factory: Any,
    final_store: Any,
    subagents: list[Any],
    skills: list[str] | None,
    model: str | None,
) -> dict[str, Any]:
    """Assemble the kwargs dict to pass to ``create_deep_agent()``."""
    kwargs: dict[str, Any] = {
        "model": _qualify_model(model) if model else config.effective_model_string,
        "tools": tools or None,
        "system_prompt": config.effective_prompt,
        "checkpointer": None,  # filled in by caller after building
        "name": config.name,
    }
    if subagents:
        kwargs["subagents"] = subagents
    if backend_factory is not None:
        kwargs["backend"] = backend_factory
    if final_store is not None:
        kwargs["store"] = final_store
    if skills:
        kwargs["skills"] = skills
    if config.interrupt_on is not None:
        kwargs["interrupt_on"] = config.interrupt_on
    if config.context_schema:
        ctx_cls = _import_context_schema(config.context_schema)
        if ctx_cls is not None:
            kwargs["context_schema"] = ctx_cls
    mw = _build_middleware_list(config, "create_runtime")
    if mw:
        kwargs["middleware"] = mw
    return kwargs


def _create_runtime_sync(
    config: ServiceConfig,
    root_dir: str | Path | None = None,
    checkpointer: Any = None,
    model: str | None = None,
    store: Any = None,
    static_tool_map: dict[str, Any] | None = None,
    dynamic_servers: list[Any] | None = None,
    dynamic_tool_descriptions: dict[str, str] | None = None,
    mcp_ctx: Any = None,
    mcp_server_infos: list[MCPServerInfo] | None = None,
) -> AgentRuntime:
    """Build a live :class:`AgentRuntime` from a loaded :class:`ServiceConfig`.

    Args:
        config: Fully resolved service config (from :func:`load_service`).
        root_dir: Optional root directory for filesystem backends.
        checkpointer: LangGraph checkpointer.  Defaults to :class:`InMemorySaver`.
        model: Optional model string to override the YAML-configured model at call
            time (e.g. ``"openai:gpt-4o"`` or bare ``"claude-sonnet-4-6"``).
            Bare names are prefixed with ``anthropic:``.
        static_tool_map: Pre-built map of ``"server/tool"`` → LangChain tool for static
            MCP servers (resolved before entering this thread).
        dynamic_servers: MCP server configs that contain dynamic placeholders
            (``${thread_id}`` / ``${context.X}``); resolved per-invocation.
        dynamic_tool_descriptions: Descriptions discovered during probe of dynamic
            servers, to inject into the system prompt.
        mcp_ctx: :class:`AsyncExitStack` holding persistent MCP sessions.  Closed by
            :meth:`AgentRuntime.aclose`.
        mcp_server_infos: Metadata for each connected static MCP server.

    Returns:
        An :class:`AgentRuntime` ready to ``invoke`` or ``stream``.
    """
    agent_config = config.entrypoint_agent
    if agent_config is None:
        raise ValueError("ServiceConfig has no entrypoint_agent; call load_service() first.")

    if config.langsmith_project_name:
        os.environ["LANGCHAIN_PROJECT"] = config.langsmith_project_name
        os.environ["LANGCHAIN_TRACING_V2"] = "true"

    if checkpointer is None:
        checkpointer = InMemorySaver()

    static_tool_map = static_tool_map or {}
    dynamic_servers = dynamic_servers or []
    dynamic_tool_descriptions = dynamic_tool_descriptions or {}

    regular_names = [t for t in agent_config.tools if not t.startswith("mcp:")]
    mcp_refs = [t[len("mcp:"):] for t in agent_config.tools if t.startswith("mcp:")]

    resolved_tools = resolve_tools(regular_names) if regular_names else []

    # Build a combined key set for wildcard expansion:
    # - static servers: real tool objects from static_tool_map
    # - dynamic servers: stub entries from probed descriptions (value None — just for key lookup)
    combined_for_wildcards: dict[str, Any] = {**static_tool_map}
    for k in dynamic_tool_descriptions:
        if k not in combined_for_wildcards:
            combined_for_wildcards[k] = None  # placeholder for wildcard expansion only

    expanded_mcp_names = _expand_mcp_wildcards(mcp_refs, combined_for_wildcards) if mcp_refs else []
    static_mcp_tools = [static_tool_map[n] for n in expanded_mcp_names if n in static_tool_map]
    dynamic_mcp_names = [n for n in expanded_mcp_names if n not in static_tool_map]

    tools = resolved_tools + static_mcp_tools
    if dynamic_mcp_names:
        tools.append(_make_mcp_dispatch_tool())

    _root_dir = Path(root_dir) if root_dir else config.root_dir
    _skills_dir = _resolve_skills_dir(config, _root_dir)

    backend_factory, backend_store = build_backend(agent_config, root_dir=_root_dir)

    store_ctx = None
    if store is not None:
        final_store = store
    elif agent_config.store is not None:
        final_store, store_ctx = build_store(agent_config.store)
    else:
        final_store = backend_store

    subagents = _build_subagents_list(agent_config)

    # Skills — single source at /skills/ for the main agent.
    skills = ["/skills/"] if agent_config.skills else None
    if agent_config.skills and _skills_dir:
        backend_factory = build_skills_backend_factory(backend_factory, _skills_dir)
    elif agent_config.skills and not _skills_dir:
        warnings.warn(
            f"Agent '{agent_config.name}' declares skills but skills_dir could not be resolved "
            "(no root_dir available). Skills will be unavailable at runtime. "
            "Pass root_dir= to create_runtime() or set skills_dir: in main.yaml.",
            stacklevel=2,
        )

    kwargs = _build_create_agent_kwargs(
        agent_config, tools, backend_factory, final_store, subagents, skills, model
    )
    kwargs["checkpointer"] = checkpointer

    if dynamic_tool_descriptions:
        kwargs["system_prompt"] = _inject_dynamic_mcp_prompt(
            kwargs.get("system_prompt"), dynamic_tool_descriptions
        )

    _isolation_variable = _get_isolation_variable(agent_config)
    agent = create_deep_agent(**kwargs)

    # --- file access metadata ---
    if agent_config.composite_backend:
        _backend_kind = "composite"
    elif agent_config.backend and agent_config.backend.type != "state":
        _backend_kind = "simple"
    else:
        _backend_kind = "state"   # covers no backend + explicit backend: state

    _has_isolation = False
    if agent_config.composite_backend:
        cb = agent_config.composite_backend
        if cb.isolation and cb.isolation.mode != "none":
            _has_isolation = True
        for rv in cb.routes.values():
            if not isinstance(rv, str) and getattr(rv, "isolation", None) and rv.isolation.mode != "none":
                _has_isolation = True
    elif agent_config.backend:
        iso = getattr(agent_config.backend, "isolation", None)
        if iso and iso.mode != "none":
            _has_isolation = True

    return AgentRuntime(
        agent,
        config.name,
        checkpointer,
        store_ctx=store_ctx,
        isolation_variable=_isolation_variable,
        dynamic_mcp_configs=dynamic_servers,
        dynamic_mcp_tool_names=dynamic_mcp_names,
        # MCP session lifecycle:
        mcp_ctx=mcp_ctx,
        mcp_server_infos=mcp_server_infos,
        # file access:
        backend_kind=_backend_kind,
        has_isolation=_has_isolation,
        backend_factory=backend_factory,
        agent_config=agent_config,
        root_dir=_root_dir,
        skills_dir=_skills_dir if (agent_config.skills and _skills_dir) else None,
    )


async def create_runtime(
    config: ServiceConfig,
    root_dir: str | Path | None = None,
    checkpointer: Any = None,
    model: str | None = None,
    store: Any = None,
) -> AgentRuntime:
    """Build a live :class:`AgentRuntime` from a loaded :class:`ServiceConfig`.

    Runs blocking I/O (skill file reads, module imports) in a thread pool so
    the event loop is not blocked.  MCP server connections (async) are established
    before entering the thread.

    Args:
        config: Fully resolved service config (from :func:`load_service`).
        root_dir: Optional root directory for filesystem backends.
        checkpointer: LangGraph checkpointer.  Defaults to :class:`InMemorySaver`.
        model: Optional model string to override the YAML-configured model at call
            time (e.g. ``"openai:gpt-4o"`` or bare ``"claude-sonnet-4-6"``).
            Bare names are prefixed with ``anthropic:``.
        store: Optional store instance (e.g. ``PostgresStore``) to override the
            service-level ``store:`` config.  Caller is responsible for lifecycle
            management when passing a store directly.

    Returns:
        An :class:`AgentRuntime` ready to ``invoke`` or ``stream``.
    """
    agent_config = config.entrypoint_agent
    if agent_config is None:
        raise ValueError("ServiceConfig has no entrypoint_agent; call load_service() first.")

    # Warn about subagents with mcp_servers (out of scope this iteration)
    for sub in (agent_config.resolved_subagents or []):
        if sub.mcp_servers:
            warnings.warn(
                f"Subagent '{sub.name}' declares mcp_servers but per-subagent MCP is not "
                "supported in this release. mcp_servers will be ignored.",
                stacklevel=2,
            )

    # Async MCP preamble (before asyncio.to_thread)
    static_tool_map: dict[str, Any] = {}
    dynamic_tool_descriptions: dict[str, str] = {}
    dynamic_servers: list[Any] = []
    mcp_exit_stack: AsyncExitStack | None = None
    mcp_server_infos: list[MCPServerInfo] = []

    if agent_config.mcp_servers:
        static_servers, dynamic_servers = _partition_mcp_servers(agent_config.mcp_servers)
        if static_servers:
            static_tool_map, mcp_exit_stack, mcp_server_infos = (
                await _build_static_mcp_tools(static_servers)
            )
        if dynamic_servers:
            dynamic_tool_descriptions = await _probe_dynamic_mcp_tools(dynamic_servers)

    # Sync blocking work in thread
    return await asyncio.to_thread(
        _create_runtime_sync,
        config, root_dir, checkpointer, model, store,
        static_tool_map, dynamic_servers, dynamic_tool_descriptions,
        mcp_exit_stack, mcp_server_infos,
    )
