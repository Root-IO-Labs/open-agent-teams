"""deep-loom-kit — YAML-driven multi-agent SDK built on deepagents.

Public API::

    from deep_loom_kit import load_service, create_runtime, register_tool

    register_tool("my_tool", my_callable)
    service = await load_service("path/to/main.yaml")
    runtime = await create_runtime(service)
    result = await runtime.invoke([{"role": "user", "content": "Hello"}], thread_id="session-1")
"""

from langchain.agents.middleware.types import AgentMiddleware
from .compiled_agents import (
    auto_register_compiled_agents,
    register_compiled_agent,
    resolve_compiled_agents,
)
from .factory import create_runtime
from .loader import load_service
from .middleware import (
    DatetimeMiddleware,
    auto_register_middleware,
    register_middleware,
    resolve_middleware,
)
from .runtime import AgentRuntime
from .schema import (
    AgentConfig,
    AgentStoreConfig,
    FilesystemBackendConfig,
    HttpMCPServerConfig,
    IsolationConfig,
    LocalShellBackendConfig,
    MCPServerConfig,
    MCPServerInfo,
    MCPToolInfo,
    PostgresStoreConfig,
    S3BackendConfig,
    ServiceConfig,
    ServiceStoreConfig,
    StateBackendConfig,
    StdioMCPServerConfig,
    StoreBackendConfig,
)
from .tools import auto_register_tools, get_thread_id, register_tool, resolve_tools
from .backends import FileDownloadResponse, FileInfo, FileUploadResponse, WriteResult

__all__ = [
    "load_service",
    "create_runtime",
    "auto_register_compiled_agents",
    "auto_register_middleware",
    "auto_register_tools",
    "register_compiled_agent",
    "register_middleware",
    "register_tool",
    "resolve_compiled_agents",
    "resolve_middleware",
    "resolve_tools",
    "get_thread_id",
    "AgentMiddleware",
    "DatetimeMiddleware",
    "AgentRuntime",
    "AgentConfig",
    "AgentStoreConfig",
    "FilesystemBackendConfig",
    "HttpMCPServerConfig",
    "IsolationConfig",
    "LocalShellBackendConfig",
    "MCPServerConfig",
    "MCPServerInfo",
    "MCPToolInfo",
    "PostgresStoreConfig",
    "S3BackendConfig",
    "ServiceConfig",
    "ServiceStoreConfig",
    "StateBackendConfig",
    "StdioMCPServerConfig",
    "StoreBackendConfig",
    "FileDownloadResponse",
    "FileInfo",
    "FileUploadResponse",
    "WriteResult",
]
