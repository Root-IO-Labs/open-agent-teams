"""Compiled-agent registry for deep-loom-kit."""

from __future__ import annotations

import importlib.util
import inspect
import warnings
from pathlib import Path

from deepagents import CompiledSubAgent

_COMPILED_AGENT_REGISTRY: dict[str, CompiledSubAgent] = {}


def _is_compiled_sub_agent(obj: object) -> bool:
    """Duck-type check: CompiledSubAgent is a TypedDict (plain dict at runtime)."""
    return (
        isinstance(obj, dict)
        and "name" in obj
        and "description" in obj
        and "runnable" in obj
    )


def register_compiled_agent(agent: CompiledSubAgent) -> None:
    """Register a CompiledSubAgent under its .name key."""
    _COMPILED_AGENT_REGISTRY[agent["name"]] = agent


def auto_register_compiled_agents(agents_dir: Path, required: set[str] | None = None) -> list[str]:
    """Import every *.py in agents_dir and register CompiledSubAgent dicts found.

    Returns list of newly registered names (skips already-registered names).
    If directory absent → returns []. Import errors → warns and continues.

    Args:
        agents_dir: Directory to scan.
        required: Names to register.  Only agents whose ``name`` appears in
            this set are registered.  When ``None`` or empty nothing is registered.
    """
    agents_dir = Path(agents_dir)
    if not agents_dir.is_dir():
        return []
    registered: list[str] = []
    for py_file in sorted(agents_dir.glob("*.py")):
        spec = importlib.util.spec_from_file_location(py_file.stem, py_file)
        if spec is None or spec.loader is None:
            continue
        module = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(module)  # type: ignore[union-attr]
        except Exception:
            warnings.warn(
                f"auto_register_compiled_agents: could not import {py_file}"
            )
            continue
        for obj_name, obj in inspect.getmembers(module):
            if obj_name.startswith("_"):
                continue
            if _is_compiled_sub_agent(obj):
                name = obj["name"]
                if required and name not in _COMPILED_AGENT_REGISTRY and name in required:
                    register_compiled_agent(obj)
                    registered.append(name)
    return registered


def resolve_compiled_agents(names: list[str]) -> list[CompiledSubAgent]:
    """Resolve a list of names to registered CompiledSubAgent dicts.

    Raises ValueError for any unknown name.
    """
    result, missing = [], []
    for name in names:
        if name in _COMPILED_AGENT_REGISTRY:
            result.append(_COMPILED_AGENT_REGISTRY[name])
        else:
            missing.append(name)
    if missing:
        raise ValueError(f"Unregistered compiled agents: {', '.join(missing)}")
    return result
