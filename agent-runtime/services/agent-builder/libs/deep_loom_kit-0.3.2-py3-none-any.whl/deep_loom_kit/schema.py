"""Pydantic v2 config models for deep-loom-kit YAML schemas."""

from __future__ import annotations

from dataclasses import dataclass, field as _dc_field
from pathlib import Path
from typing import Annotated, Literal, Optional, Union

from pydantic import BaseModel, Field, field_validator, model_validator


class IsolationConfig(BaseModel):
    """Backend path/namespace isolation configuration.

    When set, the SDK automatically appends an isolation key to the backend's
    root path or store namespace at invocation time.

    Modes:
        none      — no isolation (default)
        thread_id — namespace by LangGraph thread_id
        context   — namespace by a named attribute on the runtime context object
    """
    mode: Literal["none", "thread_id", "context"] = "none"
    variable: Optional[str] = None  # required when mode == "context"

    @model_validator(mode="after")
    def _validate(self) -> "IsolationConfig":
        if self.mode == "context" and not self.variable:
            raise ValueError("isolation.variable is required when mode is 'context'")
        return self



class StateBackendConfig(BaseModel):
    type: Literal["state"] = "state"


class StoreBackendConfig(BaseModel):
    type: Literal["store"] = "store"
    isolation: Optional[IsolationConfig] = None
    include_route: bool = True  # False → suppress route name in store namespace


class FilesystemBackendConfig(BaseModel):
    type: Literal["filesystem"] = "filesystem"
    root_dir: Optional[str] = None
    virtual_mode: bool = True
    isolation: Optional[IsolationConfig] = None
    include_route: bool = True  # False → suppress route name in resolved root path


class LocalShellBackendConfig(BaseModel):
    type: Literal["local_shell"] = "local_shell"
    root_dir: Optional[str] = None
    virtual_mode: bool = True
    timeout: int = 120
    max_output_bytes: int = 100_000
    env: Optional[dict[str, str]] = None
    inherit_env: bool = False
    isolation: Optional[IsolationConfig] = None
    include_route: bool = True  # False → suppress route name in resolved root path

    @field_validator("timeout")
    @classmethod
    def _validate_timeout(cls, v: int) -> int:
        if v <= 0:
            raise ValueError(f"timeout must be > 0, got {v}")
        return v

    @field_validator("max_output_bytes")
    @classmethod
    def _validate_max_output_bytes(cls, v: int) -> int:
        if v <= 0:
            raise ValueError(f"max_output_bytes must be > 0, got {v}")
        return v


class S3BackendConfig(BaseModel):
    type: Literal["s3"] = "s3"
    bucket: str
    prefix: str = ""
    # All connection config (credentials, region, endpoint, timeouts) is read from
    # environment variables at runtime — see backends._resolve_s3_env_kwargs() for
    # the full list of supported env vars (AWS_ACCESS_KEY_ID, AWS_DEFAULT_REGION, etc.)
    isolation: Optional[IsolationConfig] = None
    include_route: bool = True  # False → suppress route name in S3 prefix


BackendConfig = Annotated[
    Union[
        StateBackendConfig,
        StoreBackendConfig,
        FilesystemBackendConfig,
        LocalShellBackendConfig,
        S3BackendConfig,
    ],
    Field(discriminator="type"),
]


class StdioMCPServerConfig(BaseModel):
    name: str
    type: Literal["stdio"] = "stdio"
    command: str
    args: list[str] = Field(default_factory=list)
    env: dict[str, str] = Field(default_factory=dict)
    # max_connections silently ignored for static servers (connected once at create_runtime time)
    max_connections: int = 10


class HttpMCPServerConfig(BaseModel):
    name: str
    type: Literal["http"] = "http"
    url: str
    headers: dict[str, str] = Field(default_factory=dict)


MCPServerConfig = Annotated[
    Union[StdioMCPServerConfig, HttpMCPServerConfig],
    Field(discriminator="type"),
]


@dataclass
class MCPToolInfo:
    """Metadata for a single MCP tool exposed by a connected server."""

    name: str
    """Tool name as registered in the agent's tool list (``server/tool_name`` format)."""

    description: str
    """Human-readable description of the tool."""


@dataclass
class MCPServerInfo:
    """Metadata for a connected MCP server and its tools."""

    name: str
    """Server name from the YAML ``mcp_servers:`` config."""

    transport: str
    """Transport type: ``"stdio"`` or ``"http"``."""

    tools: list[MCPToolInfo] = _dc_field(default_factory=list)
    """Tools exposed by this server."""


class PostgresStoreConfig(BaseModel):
    type: Literal["postgres"] = "postgres"
    connection_string_env: str
    pool_size: int = 5
    max_overflow: int = 10

    @model_validator(mode="after")
    def _validate_env_var_name(self) -> "PostgresStoreConfig":
        if not self.connection_string_env:
            raise ValueError("connection_string_env must be a non-empty environment variable name")
        return self


AgentStoreConfig = Annotated[
    Union[PostgresStoreConfig],
    Field(discriminator="type"),
]

# Backward-compatible alias
ServiceStoreConfig = AgentStoreConfig


class CompositeBackendConfig(BaseModel):
    default: "str | BackendConfig" = "state"
    routes: dict[str, "str | BackendConfig"] = Field(default_factory=dict)
    isolation: Optional[IsolationConfig] = None


class AgentConfig(BaseModel):
    name: str
    description: Optional[str] = None
    type: Optional[str] = None
    role: Optional[str] = None

    # Model fields — default_model is normalised → model
    model: Optional[str] = None
    default_model: Optional[str] = None

    # Temperature fields — default_temperature is normalised → temperature
    temperature: Optional[float] = None
    default_temperature: Optional[float] = None

    # Prompt fields — prompt is an alias for system_prompt
    system_prompt: Optional[str] = None
    prompt: Optional[str] = None

    skills: list[str] = Field(default_factory=list)
    tools: list[str] = Field(default_factory=list)
    middleware: list[str] = Field(default_factory=list)
    interrupt_on: Optional[dict[str, bool]] = None
    subagents: list[str] = Field(default_factory=list)
    compiledagents: list[str] = Field(default_factory=list)
    data_sources: list[str] = Field(default_factory=list)  # reserved — loaded/ignored at runtime; no SDK wiring yet
    mcp_servers: list[MCPServerConfig] = Field(default_factory=list)

    # Backend config — mutually exclusive; composite_backend takes precedence
    backend: Optional[BackendConfig] = None
    composite_backend: Optional[CompositeBackendConfig] = None

    # Runtime context schema — dotted import path to a dataclass, e.g. "myapp.contexts.UserContext"
    context_schema: Optional[str] = None

    # Inject current date/time into every model call's system message (default: True)
    datetime_awareness: bool = True

    # Agent-level store configuration (production persistence via LangGraph BaseStore)
    store: Optional[PostgresStoreConfig] = None

    # Populated by ConfigLoader after recursive resolution; not from YAML
    resolved_subagents: list[AgentConfig] = Field(default_factory=list)

    model_config = {"populate_by_name": True}

    @model_validator(mode="before")
    @classmethod
    def _coerce_backend_string(cls, values: object) -> object:
        """Allow ``backend: filesystem`` (bare string) in YAML."""
        if isinstance(values, dict) and "backend" in values:
            b = values["backend"]
            if isinstance(b, str):
                values["backend"] = {"type": b.lower()}
        return values

    @model_validator(mode="after")
    def _normalise_fields(self) -> AgentConfig:
        if self.default_model and not self.model:
            self.model = self.default_model
        if self.default_temperature is not None and self.temperature is None:
            self.temperature = self.default_temperature
        return self

    @property
    def effective_prompt(self) -> Optional[str]:
        """Return system_prompt, falling back to prompt."""
        return self.system_prompt or self.prompt

    @property
    def effective_model_string(self) -> Optional[str]:
        """Return model string with provider prefix (e.g. ``anthropic:claude-sonnet-4-5``)."""
        if self.model:
            return self.model if ":" in self.model else f"anthropic:{self.model}"
        return None


class ServiceConfig(BaseModel):
    name: str
    version: Optional[str] = None
    entrypoint: str
    type: Optional[str] = None
    langsmith_project_name: Optional[str] = None

    # Optional path overrides (absolute or relative to the service directory)
    tools_dir: Optional[str] = None            # default: <service-dir>/../tools/
    compiled_agents_dir: Optional[str] = None  # default: <service-dir>/compiled_agents/
    skills_dir: Optional[str] = None           # default: <root_dir>/skills/
    middleware_dir: Optional[str] = None       # default: <service-dir>/middleware/

    # Populated by ConfigLoader after resolving the entrypoint YAML; not from YAML
    entrypoint_agent: Optional[AgentConfig] = None
    root_dir: Optional[Path] = None
