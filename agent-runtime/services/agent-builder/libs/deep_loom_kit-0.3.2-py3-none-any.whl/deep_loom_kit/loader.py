"""YAML config loader with recursive subagent resolution."""

from __future__ import annotations

import asyncio
from pathlib import Path

import yaml

from .schema import AgentConfig, ServiceConfig


def _collect_required_names(
    service: ServiceConfig,
) -> tuple[set[str], set[str], set[str]]:
    """Walk the resolved AgentConfig tree and return sets of required names.

    Returns:
        A 3-tuple of ``(tool_names, middleware_names, compiled_agent_names)``
        collected from the entrypoint agent and all its resolved subagents.
    """
    tools: set[str] = set()
    mw: set[str] = set()
    ca: set[str] = set()

    def _walk(agent: AgentConfig) -> None:
        tools.update(agent.tools)
        mw.update(agent.middleware)
        ca.update(agent.compiledagents)
        for sub in agent.resolved_subagents:
            _walk(sub)

    if service.entrypoint_agent:
        _walk(service.entrypoint_agent)
    return tools, mw, ca


def _resolve_service_path(path_str: str, service_dir: Path) -> Path:
    """Resolve a config-supplied path: absolute as-is, relative → relative to service_dir."""
    p = Path(path_str)
    return p if p.is_absolute() else (service_dir / p).resolve()


class ConfigLoader:
    """Loads and recursively resolves agent YAML configurations.

    Args:
        base_dir: The root directory of the service (directory containing main.yaml).
    """

    def __init__(self, base_dir: Path) -> None:
        self.base_dir = Path(base_dir)
        self._cache: dict[Path, AgentConfig] = {}
        self._loading: set[Path] = set()

    def load_service(self, path: str | Path) -> ServiceConfig:
        """Parse main.yaml and resolve the entrypoint agent recursively.

        Args:
            path: Absolute or relative path to the service's main.yaml.

        Returns:
            A fully resolved :class:`ServiceConfig`.
        """
        service_path = Path(path).resolve()
        self.base_dir = service_path.parent

        with open(service_path) as f:
            data = yaml.safe_load(f)

        if not isinstance(data, dict):
            raise ValueError(
                f"Expected a YAML mapping in {service_path}, got {type(data).__name__}"
            )

        # Support both bare dicts and `service:` top-level key
        if "service" in data:
            data = data["service"]

        service = ServiceConfig(**data)
        service.root_dir = service_path.parent

        entrypoint_path = self._resolve_path(service.entrypoint, service_path.parent)
        service.entrypoint_agent = self._load_agent(entrypoint_path)

        req_tools, req_mw, req_ca = _collect_required_names(service)

        from .tools import auto_register_tools
        tools_dir = (
            _resolve_service_path(service.tools_dir, service_path.parent)
            if service.tools_dir
            else service_path.parent.parent / "tools"
        )
        auto_register_tools(tools_dir, required=req_tools)

        from .compiled_agents import auto_register_compiled_agents
        ca_dir = (
            _resolve_service_path(service.compiled_agents_dir, service_path.parent)
            if service.compiled_agents_dir
            else service_path.parent / "compiled_agents"
        )
        auto_register_compiled_agents(ca_dir, required=req_ca)

        from .middleware import auto_register_middleware
        mw_dir = (
            _resolve_service_path(service.middleware_dir, service_path.parent)
            if service.middleware_dir
            else service_path.parent / "middleware"
        )
        auto_register_middleware(mw_dir, required=req_mw)

        return service

    def _load_agent(self, path: Path) -> AgentConfig:
        """Parse an agent YAML and recursively resolve its subagents.

        Args:
            path: Absolute path to the agent YAML file.

        Returns:
            A fully resolved :class:`AgentConfig`.

        Raises:
            FileNotFoundError: If the YAML file does not exist.
            ValueError: If a circular reference is detected.
        """
        abs_path = path.resolve()

        if abs_path in self._cache:
            return self._cache[abs_path]

        if abs_path in self._loading:
            raise ValueError(f"Circular reference detected: {abs_path}")

        if not abs_path.exists():
            raise FileNotFoundError(f"Agent config not found: {abs_path}")

        self._loading.add(abs_path)
        try:
            with open(abs_path) as f:
                data = yaml.safe_load(f)

            agent = AgentConfig(**data)

            resolved: list[AgentConfig] = []
            for ref in agent.subagents:
                sub_path = self._resolve_path(ref, abs_path.parent)
                resolved.append(self._load_agent(sub_path))
            agent.resolved_subagents = resolved

        finally:
            self._loading.discard(abs_path)

        self._cache[abs_path] = agent
        return agent

    def _resolve_path(self, ref: str, current_dir: Path) -> Path:
        """Resolve a YAML reference to an absolute path.

        Looks first relative to *current_dir*, then falls back to the service root.
        """
        candidate = (current_dir / ref).resolve()
        if candidate.exists():
            return candidate

        fallback = (self.base_dir / ref).resolve()
        if fallback.exists():
            return fallback

        # Return the primary candidate so callers get a useful error path
        return candidate


def _load_service_sync(path: str | Path) -> ServiceConfig:
    """Synchronous helper — runs blocking I/O inline."""
    p = Path(path)
    loader = ConfigLoader(p.parent)
    return loader.load_service(p)


async def load_service(path: str | Path) -> ServiceConfig:
    """Load a service config from a YAML file path.

    Runs blocking I/O (YAML parsing, module imports) in a thread pool so the
    event loop is not blocked.

    Args:
        path: Path to the service's main.yaml file.

    Returns:
        A fully resolved :class:`ServiceConfig` with ``entrypoint_agent`` populated.
    """
    return await asyncio.to_thread(_load_service_sync, str(path))
