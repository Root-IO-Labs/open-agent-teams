"""Tool name registry for deep-loom-kit."""

import importlib.util
import inspect
import warnings
from collections.abc import Callable
from pathlib import Path
from typing import Any

from langchain_core.tools import StructuredTool

_TOOL_REGISTRY: dict[str, tuple[Callable, str]] = {}


def get_thread_id(config: Any) -> str | None:
    """Extract the current thread ID from a LangChain ``RunnableConfig``.

    Use inside a tool that accepts an injected ``RunnableConfig`` parameter:

    .. code-block:: python

        from typing import Annotated
        from langchain_core.runnables import RunnableConfig
        from langchain_core.tools import InjectedToolArg
        from deep_loom_kit import get_thread_id

        def my_tool(query: str, config: Annotated[RunnableConfig, InjectedToolArg]) -> str:
            \"\"\"My tool description.\"\"\"
            thread_id = get_thread_id(config)
            ...

    Args:
        config: The ``RunnableConfig`` injected by LangGraph at tool call time.

    Returns:
        The thread ID string, or ``None`` if not present in the config.
    """
    if not isinstance(config, dict):
        return None
    return config.get("configurable", {}).get("thread_id")


def register_tool(name: str, callable: Callable, description: str = "") -> None:
    """Register a callable under a tool name.

    Args:
        name: The tool name referenced in YAML ``tools:`` lists.
        callable: The function or ``StructuredTool`` to register.  If a
            ``StructuredTool`` (e.g. from the ``@tool`` decorator) is passed it
            is stored as-is and re-used without re-wrapping.
        description: Human-readable description used by the LLM to decide when
            to call the tool.  Falls back to the callable's ``.description``
            attribute (for ``StructuredTool``), then the docstring, then the
            tool name.

    Call this before :func:`create_runtime` so tools referenced in YAML configs
    can be resolved.
    """
    if isinstance(callable, StructuredTool):
        resolved_description = description or callable.description or name
    else:
        resolved_description = description or callable.__doc__ or name
    _TOOL_REGISTRY[name] = (callable, resolved_description)


def auto_register_tools(tools_dir: Path, required: set[str] | None = None) -> list[str]:
    """Import every *.py file in tools_dir and register only the named tools.

    Args:
        tools_dir: Directory to scan for Python tool modules.
        required: Names to register.  Only tools whose name appears in this set
            are registered.  When ``None`` or empty nothing is registered.

    Returns:
        List of newly registered tool names (skips already-registered names).
    """
    tools_dir = Path(tools_dir)
    if not tools_dir.is_dir():
        return []
    registered: list[str] = []
    for py_file in sorted(tools_dir.glob("*.py")):
        spec = importlib.util.spec_from_file_location(py_file.stem, py_file)
        if spec is None or spec.loader is None:
            continue
        module = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(module)  # type: ignore[union-attr]
        except Exception:
            warnings.warn(f"auto_register_tools: could not import {py_file}")
            continue
        for obj_name, obj in inspect.getmembers(module):
            if obj_name.startswith("_"):
                continue
            if isinstance(obj, StructuredTool):
                # @tool-decorated functions become StructuredTool instances;
                # use the tool's declared .name as the registry key.
                tool_name = obj.name
                if required and tool_name not in _TOOL_REGISTRY and tool_name in required:
                    register_tool(tool_name, obj)
                    registered.append(tool_name)
            elif inspect.isfunction(obj) and getattr(obj, "__module__", None) == module.__name__:
                if required and obj_name not in _TOOL_REGISTRY and obj_name in required:
                    register_tool(obj_name, obj)
                    registered.append(obj_name)
    return registered


def resolve_tools(names: list[str]) -> list[StructuredTool]:
    """Resolve a list of tool names to langchain StructuredTool instances.

    Raises:
        ValueError: If any name has not been registered.
    """
    tools: list[StructuredTool] = []
    missing: list[str] = []
    for name in names:
        if name in _TOOL_REGISTRY:
            fn, description = _TOOL_REGISTRY[name]
            if isinstance(fn, StructuredTool):
                tools.append(fn)
            elif inspect.iscoroutinefunction(fn):
                tools.append(
                    StructuredTool.from_function(coroutine=fn, name=name, description=description)
                )
            else:
                tools.append(
                    StructuredTool.from_function(fn, name=name, description=description)
                )
        else:
            missing.append(name)
    if missing:
        raise ValueError(f"Unregistered tools: {', '.join(missing)}")
    return tools
