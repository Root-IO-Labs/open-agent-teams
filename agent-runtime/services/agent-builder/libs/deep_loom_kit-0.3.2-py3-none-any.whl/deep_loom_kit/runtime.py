"""AgentRuntime wrapper for invoking deep agents."""

from __future__ import annotations

import warnings
from collections.abc import AsyncGenerator
from pathlib import Path
from typing import TYPE_CHECKING, Any

from langgraph.graph.state import CompiledStateGraph

if TYPE_CHECKING:
    from .schema import MCPServerInfo
    from deepagents.backends.protocol import FileUploadResponse, WriteResult


class AgentRuntime:
    """Wraps a compiled deep agent graph.

    Args:
        agent: Compiled LangGraph state graph returned by ``create_deep_agent``.
        service_name: Name of the service (used for tracing/logging).
        checkpointer: The checkpointer passed to the agent graph.
        store_ctx: Optional context manager for a store (e.g. Postgres pool).
        isolation_variable: Isolation variable name (e.g. ``"tenant_id"``) when
            ``composite_backend.isolation.mode = "context"``.  Used to warn when
            context=None is passed at invoke/stream time.
        mcp_ctx: :class:`~contextlib.AsyncExitStack` holding persistent MCP sessions
            (entered at ``create_runtime`` time, exited at ``aclose``).  ``None``
            when no static MCP servers are configured.
        mcp_server_infos: Metadata for each connected static MCP server.  Access via
            the :attr:`mcp_servers` property.
        dynamic_mcp_configs: MCP server configs that are resolved per-invocation
            (may contain template variables expanded from thread_id / context).
        dynamic_mcp_tool_names: Optional allowlist of ``"server/tool"`` strings.
            When non-empty only matching tools are included in the tool map.
        backend_kind: One of ``"state"``, ``"simple"``, or ``"composite"``.
            Determines which dispatch path ``list_files`` / ``read_file`` /
            ``download_files`` use.  Set by ``factory.py``; defaults to
            ``"state"`` (LangGraph state backend).
        has_isolation: ``True`` when the backend config includes an active
            isolation mode (``thread_id`` or ``context``).  When ``True`` and
            ``backend_kind == "simple"``, a fresh isolated backend is
            reconstructed per call rather than using the factory shortcut.
        backend_factory: The ``(ToolRuntime) -> BackendProtocol`` callable
            returned by ``build_backend``.  Required when
            ``backend_kind == "simple"`` and ``has_isolation == False``.
        agent_config: The ``AgentConfig`` for the entrypoint agent.  Required
            when ``backend_kind != "state"`` so that ``_get_backend`` can
            reconstruct isolated backends.
        root_dir: Resolved service root directory (``Path | None``).  Passed
            through to ``_build_simple`` / ``_build_composite`` for path
            construction.
        skills_dir: Resolved skills directory (``Path | None``).  When set,
            ``_build_simple`` / ``_build_composite`` wrap the backend in a
            ``_SkillsProxy`` so ``/skills/`` paths are accessible.
    """

    def __init__(
        self,
        agent: CompiledStateGraph,
        service_name: str,
        checkpointer: Any = None,
        store_ctx: Any = None,
        isolation_variable: str | None = None,
        mcp_ctx: Any = None,
        mcp_server_infos: list[Any] | None = None,
        dynamic_mcp_configs: list[Any] | None = None,
        dynamic_mcp_tool_names: list[str] | None = None,
        # --- file access support ---
        backend_kind: str = "state",
        has_isolation: bool = False,
        backend_factory: Any = None,
        agent_config: Any = None,
        root_dir: Path | None = None,
        skills_dir: Path | None = None,
    ) -> None:
        self._agent = agent
        self.service_name = service_name
        self._checkpointer = checkpointer
        self._store_ctx = store_ctx
        self._isolation_variable = isolation_variable
        self._mcp_ctx = mcp_ctx
        self._mcp_server_infos: list[MCPServerInfo] = mcp_server_infos or []
        self._dynamic_mcp_configs = dynamic_mcp_configs or []
        self._dynamic_mcp_tool_names = dynamic_mcp_tool_names or []
        self._backend_kind = backend_kind
        self._has_isolation = has_isolation
        self._backend_factory = backend_factory
        self._agent_config = agent_config
        self._root_dir = root_dir
        self._skills_dir = skills_dir

    @property
    def mcp_servers(self) -> list[MCPServerInfo]:
        """Metadata for each connected static MCP server and its tools."""
        return self._mcp_server_infos

    def _check_context_isolation(self, context: Any) -> None:
        """Warn if context isolation is configured but context=None was passed."""
        if self._isolation_variable and context is None:
            warnings.warn(
                f"Backend uses context isolation (variable={self._isolation_variable!r}) "
                "but context=None was passed to invoke/stream. "
                "The backend will raise RuntimeError when it tries to read the isolation key. "
                "Pass context=<your context object> to invoke() or stream().",
                stacklevel=3,
            )

    async def aclose(self) -> None:
        """Release resources (MCP sessions, Postgres connection pool)."""
        if self._mcp_ctx is not None:
            await self._mcp_ctx.aclose()
            self._mcp_ctx = None
        if self._store_ctx is not None:
            self._store_ctx.__exit__(None, None, None)
            self._store_ctx = None

    async def __aenter__(self) -> "AgentRuntime":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()

    async def invoke(
        self,
        messages: list[dict[str, str]],
        thread_id: str,
        context: Any = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Invoke the agent and return the final state.

        Args:
            messages: List of message dicts with ``role`` and ``content`` keys.
            thread_id: Conversation thread identifier for this call.
            context: Optional runtime context instance (dataclass matching the agent's
                ``context_schema``).  Passed through to the underlying LangGraph invoke.
            **kwargs: Additional keyword arguments forwarded directly to
                ``agent.ainvoke()`` (e.g. ``interrupt_before``, ``interrupt_after``).

        Returns:
            The final agent state dict (contains ``messages`` key with full history).
        """
        self._check_context_isolation(context)
        invoke_kwargs = {**kwargs}
        invoke_kwargs.setdefault("config", {}).setdefault("configurable", {})["thread_id"] = thread_id
        if self._dynamic_mcp_configs:
            tool_map = await self._resolve_dynamic_mcp_tools(thread_id, context)
            invoke_kwargs["config"]["configurable"]["mcp_tool_map"] = tool_map
        initial_state: dict[str, Any] = {"messages": messages}
        if context is not None:
            invoke_kwargs["context"] = context
        return await self._agent.ainvoke(initial_state, **invoke_kwargs)

    async def stream(
        self,
        messages: list[dict[str, str]],
        thread_id: str,
        context: Any = None,
        **kwargs: Any,
    ) -> AsyncGenerator[dict[str, Any], None]:
        """Stream agent output chunks.

        Args:
            messages: List of message dicts with ``role`` and ``content`` keys.
            thread_id: Conversation thread identifier for this call.
            context: Optional runtime context instance (dataclass matching the agent's
                ``context_schema``).  Passed through to the underlying LangGraph stream.
            **kwargs: Additional keyword arguments forwarded directly to
                ``agent.astream()`` (e.g. ``stream_mode``, ``subgraphs``).

        Yields:
            State update dicts from the agent graph.
        """
        self._check_context_isolation(context)
        stream_kwargs = {**kwargs}
        stream_kwargs.setdefault("config", {}).setdefault("configurable", {})["thread_id"] = thread_id
        if self._dynamic_mcp_configs:
            tool_map = await self._resolve_dynamic_mcp_tools(thread_id, context)
            stream_kwargs["config"]["configurable"]["mcp_tool_map"] = tool_map
        initial_state: dict[str, Any] = {"messages": messages}
        if context is not None:
            stream_kwargs["context"] = context
        async for chunk in self._agent.astream(initial_state, **stream_kwargs):
            yield chunk

    async def get_state(self, thread_id: str, **kwargs: Any) -> Any:
        """Return the current checkpointed state for a thread.

        Args:
            thread_id: Thread to inspect.
            **kwargs: Additional keyword arguments forwarded to ``agent.aget_state()``.
                Notable options:

                - ``subgraphs`` (:class:`bool`): Return subgraph state snapshots
                  alongside the top-level snapshot.
                - ``config`` (:class:`dict`): A LangGraph ``RunnableConfig`` dict
                  whose ``configurable`` values (e.g. ``checkpoint_id``,
                  ``checkpoint_ns``) are merged with ``thread_id`` before the call.

        Returns:
            LangGraph ``StateSnapshot`` for the thread.
        """
        config = kwargs.pop("config", {})
        config.setdefault("configurable", {})["thread_id"] = thread_id
        return await self._agent.aget_state(config, **kwargs)

    async def _get_backend(self, thread_id: str, context: Any = None, **kwargs: Any) -> Any:
        """Resolve a backend for external file access (read and write).

        ``**kwargs`` are forwarded to ``get_state()`` when the backend kind is
        ``"state"`` or ``"composite"``, allowing callers to target a specific
        checkpoint (e.g. ``config={"configurable": {"checkpoint_id": "..."}}``)`.
        """
        from .backends._external import _StateFileAccessor, _build_composite, _build_simple

        if self._backend_kind == "state":
            snapshot = await self.get_state(thread_id, **kwargs)
            return _StateFileAccessor(snapshot.values.get("files", {}))
        if self._backend_kind == "composite":
            return await _build_composite(self, thread_id, context, **kwargs)
        # simple backend from here
        if self._has_isolation:
            return _build_simple(self, thread_id, context)
        if self._backend_factory is None:
            raise RuntimeError(
                "backend_kind='simple' requires backend_factory to be set. "
                "This AgentRuntime was constructed without a backend_factory."
            )
        return self._backend_factory(self._agent)

    async def list_files(
        self, thread_id: str, path: str = "/", context: Any = None, **kwargs: Any,
    ) -> list:
        """List files in the agent backend for a given thread.

        Args:
            thread_id: Thread to read files for.
            path: Directory path to list (default: root).
            context: Optional runtime context (required for context-isolation backends).
            **kwargs: Forwarded to ``get_state()`` — e.g.
                ``config={"configurable": {"checkpoint_id": "..."}}`` to read
                files from a specific checkpoint.
        """
        backend = await self._get_backend(thread_id, context, **kwargs)
        return backend.ls_info(path)

    async def read_file(
        self, thread_id: str, file_path: str, context: Any = None,
        offset: int = 0, limit: int = 2000, **kwargs: Any,
    ) -> str:
        """Read a file from the agent backend.

        Args:
            thread_id: Thread to read files for.
            file_path: Absolute path of file to read.
            context: Optional runtime context.
            offset: Line offset (0-indexed).
            limit: Maximum lines to return.
            **kwargs: Forwarded to ``get_state()`` — e.g.
                ``config={"configurable": {"checkpoint_id": "..."}}`` to read
                files from a specific checkpoint.
        """
        backend = await self._get_backend(thread_id, context, **kwargs)
        return backend.read(file_path, offset, limit)

    async def download_files(
        self, thread_id: str, paths: list[str], context: Any = None, **kwargs: Any,
    ) -> list:
        """Download files from the agent backend.

        Args:
            thread_id: Thread to read files for.
            paths: List of file paths to download.
            context: Optional runtime context.
            **kwargs: Forwarded to ``get_state()`` — e.g.
                ``config={"configurable": {"checkpoint_id": "..."}}`` to read
                files from a specific checkpoint.
        """
        backend = await self._get_backend(thread_id, context, **kwargs)
        return backend.download_files(paths)

    async def upload_files(
        self,
        thread_id: str,
        files: list[tuple[str, bytes]],
        context: Any = None,
        **kwargs: Any,
    ) -> "list[FileUploadResponse]":
        """Upload files into the agent backend for a given thread.

        Args:
            thread_id: Thread to write files for.
            files: List of (path, content_bytes) tuples.
            context: Optional runtime context (required for context-isolation backends).
            **kwargs: Forwarded to ``get_state()`` — e.g.
                ``config={"configurable": {"checkpoint_id": "..."}}`` to target
                a specific checkpoint.

        Raises:
            NotImplementedError: If the backend is state-based. State is owned
                by the agent graph — seed files via the initial message or use
                a filesystem/S3/store backend instead.
        """
        if self._backend_kind == "state":
            raise NotImplementedError(
                "upload_files is not supported for state backends. "
                "State is owned by the agent graph — seed files by passing them "
                "in the initial message or use a filesystem/S3/store backend instead."
            )
        backend = await self._get_backend(thread_id, context, **kwargs)
        return backend.upload_files(files)

    async def write_file(
        self,
        thread_id: str,
        file_path: str,
        content: str,
        context: Any = None,
        **kwargs: Any,
    ) -> "WriteResult":
        """Write a file into the agent backend for a given thread.

        Args:
            thread_id: Thread to write files for.
            file_path: Absolute path of file to write.
            content: Text content to write.
            context: Optional runtime context (required for context-isolation backends).
            **kwargs: Forwarded to ``get_state()`` — e.g.
                ``config={"configurable": {"checkpoint_id": "..."}}`` to target
                a specific checkpoint.

        Raises:
            NotImplementedError: If the backend is state-based. State is owned
                by the agent graph — seed files by passing them in the initial
                message or use a filesystem/S3/store backend instead.

        Returns:
            WriteResult with ``path`` and ``error`` fields. ``files_update`` is
            an internal LangGraph mechanism and can be ignored by external callers.
        """
        if self._backend_kind == "state":
            raise NotImplementedError(
                "write_file is not supported for state backends. "
                "State is owned by the agent graph — seed files by passing them "
                "in the initial message or use a filesystem/S3/store backend instead."
            )
        backend = await self._get_backend(thread_id, context, **kwargs)
        return backend.write(file_path, content)

    async def overwrite_file(
        self,
        thread_id: str,
        file_path: str,
        content: str,
        context: Any = None,
        **kwargs: Any,
    ) -> "FileUploadResponse":
        """Overwrite a file in the agent backend, creating it if it does not exist.

        Unlike ``write_file``, this method succeeds even when the file already
        exists — the existing content is replaced unconditionally.

        Args:
            thread_id: Thread to write files for.
            file_path: Absolute path of file to write.
            content: Text content to write.
            context: Optional runtime context (required for context-isolation backends).
            **kwargs: Forwarded to ``get_state()`` — e.g.
                ``config={"configurable": {"checkpoint_id": "..."}}`` to target
                a specific checkpoint.

        Raises:
            NotImplementedError: If the backend is state-based. State is owned
                by the agent graph — seed files by passing them in the initial
                message or use a filesystem/S3/store backend instead.

        Returns:
            FileUploadResponse with ``path`` and ``error`` fields.
        """
        if self._backend_kind == "state":
            raise NotImplementedError(
                "overwrite_file is not supported for state backends. "
                "State is owned by the agent graph — seed files by passing them "
                "in the initial message or use a filesystem/S3/store backend instead."
            )
        backend = await self._get_backend(thread_id, context, **kwargs)
        results = backend.upload_files([(file_path, content.encode("utf-8"))])
        return results[0]

    async def _resolve_dynamic_mcp_tools(
        self, thread_id: str, context: Any
    ) -> dict[str, Any]:
        """Build tool map for dynamic MCP servers at invoke/stream time."""
        from .factory import _expand_mcp_template, _make_mcp_client
        from .schema import HttpMCPServerConfig as _Http, StdioMCPServerConfig as _Stdio

        tool_map: dict[str, Any] = {}

        for server in self._dynamic_mcp_configs:
            data = server.model_dump()
            for k, v in data.items():
                if isinstance(v, str):
                    data[k] = _expand_mcp_template(v, thread_id=thread_id, context=context)
                elif isinstance(v, list):
                    data[k] = [
                        _expand_mcp_template(x, thread_id=thread_id, context=context)
                        if isinstance(x, str) else x for x in v
                    ]
                elif isinstance(v, dict):
                    data[k] = {
                        dk: _expand_mcp_template(dv, thread_id=thread_id, context=context)
                        if isinstance(dv, str) else dv
                        for dk, dv in v.items()
                    }

            if isinstance(server, _Stdio):
                resolved = _Stdio(**data)
                client = _make_mcp_client([resolved])
                tools = await client.get_tools()
            else:
                resolved = _Http(**data)
                client = _make_mcp_client([resolved])
                tools = await client.get_tools()

            for tool in tools:
                if "__" in tool.name:
                    _sname, tool_name = tool.name.split("__", 1)
                else:
                    tool_name = tool.name
                ns_key = f"{server.name}/{tool_name}"
                if not self._dynamic_mcp_tool_names or ns_key in self._dynamic_mcp_tool_names:
                    tool_map[ns_key] = tool

        return tool_map
