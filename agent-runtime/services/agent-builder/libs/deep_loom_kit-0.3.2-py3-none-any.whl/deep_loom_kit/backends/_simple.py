"""Simple (non-composite) backend builder."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from ._isolation import _make_path_factory, _make_store_factory
from ._s3 import _make_s3_factory


def _resolve_root(cfg_root_dir: str | None, root_dir: Path | None) -> str | None:
    """Resolve a config-supplied root_dir against the service root.

    - Absolute paths are returned unchanged.
    - Relative paths are resolved against *root_dir* (the service directory).
    - If *cfg_root_dir* is absent, falls back to *root_dir*.
    """
    if cfg_root_dir:
        raw = Path(cfg_root_dir)
        if raw.is_absolute():
            return str(raw)
        if root_dir:
            return str((root_dir / raw).resolve())
        raise ValueError(
            f"Backend root_dir {str(cfg_root_dir)!r} is a relative path but no service "
            "directory is available to resolve it against. Use an absolute path."
        )
    return str(root_dir) if root_dir else None


def _build_simple_backend(
    cfg: Any,
    root_dir: Path | None,
) -> tuple[Any, Any]:
    """Build a (backend_or_factory, store) pair from a simple BackendConfig.

    Backend classes and helpers are imported lazily from ``deep_loom_kit.backends``
    so that tests can patch them via ``patch("deep_loom_kit.backends.XYZ")``.
    """
    from langgraph.store.memory import InMemoryStore

    from ..schema import (
        FilesystemBackendConfig,
        LocalShellBackendConfig,
        S3BackendConfig,
        StoreBackendConfig,
    )

    if isinstance(cfg, StoreBackendConfig):
        return _make_store_factory(cfg.isolation), InMemoryStore()

    if isinstance(cfg, FilesystemBackendConfig):
        fs_root = _resolve_root(cfg.root_dir, root_dir)
        return _make_path_factory("filesystem", fs_root, cfg.virtual_mode, cfg.isolation), None

    if isinstance(cfg, LocalShellBackendConfig):
        ls_root = _resolve_root(cfg.root_dir, root_dir)
        extra = {
            "timeout": cfg.timeout,
            "max_output_bytes": cfg.max_output_bytes,
            "env": cfg.env,
            "inherit_env": cfg.inherit_env,
        }
        return _make_path_factory("local_shell", ls_root, cfg.virtual_mode, cfg.isolation, extra), None

    if isinstance(cfg, S3BackendConfig):
        return _make_s3_factory(cfg, cfg.isolation), None

    # StateBackendConfig or unknown → use deepagents default
    return None, None
