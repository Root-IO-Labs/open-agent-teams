"""S3 backend helpers — env resolution, building, and isolation factories."""

from __future__ import annotations

import os
from typing import Any

from ._isolation import _resolve_isolation_key


def _resolve_s3_env_kwargs() -> dict:
    """Read S3 connection config from environment variables at runtime.

    Supported env vars
    ------------------
    AWS_ACCESS_KEY_ID        → access_key_id
    AWS_SECRET_ACCESS_KEY    → secret_access_key
    AWS_DEFAULT_REGION       → region  (falls back to AWS_REGION)
    AWS_ENDPOINT_URL         → endpoint_url  (for MinIO / S3-compatible storage)
    S3_USE_SSL               → use_ssl  ("true"/"false")
    S3_MAX_POOL_CONNECTIONS  → max_pool_connections  (int)
    S3_CONNECT_TIMEOUT       → connect_timeout  (float, seconds)
    S3_READ_TIMEOUT          → read_timeout  (float, seconds)
    S3_MAX_RETRIES           → max_retries  (int)
    """
    kwargs: dict = {}
    if v := os.environ.get("AWS_ACCESS_KEY_ID"):
        kwargs["access_key_id"] = v
    if v := os.environ.get("AWS_SECRET_ACCESS_KEY"):
        kwargs["secret_access_key"] = v
    region = os.environ.get("AWS_DEFAULT_REGION") or os.environ.get("AWS_REGION")
    if region:
        kwargs["region"] = region
    if v := os.environ.get("AWS_ENDPOINT_URL"):
        kwargs["endpoint_url"] = v
    if v := os.environ.get("S3_USE_SSL"):
        _truthy = ("true", "1", "yes")
        _falsy = ("false", "0", "no")
        vl = v.lower()
        if vl in _truthy:
            kwargs["use_ssl"] = True
        elif vl in _falsy:
            kwargs["use_ssl"] = False
        else:
            raise ValueError(
                f"S3_USE_SSL={v!r} is not a recognised boolean. "
                f"Use one of: {_truthy + _falsy}"
            )
    _int_vars = {"S3_MAX_POOL_CONNECTIONS": "max_pool_connections", "S3_MAX_RETRIES": "max_retries"}
    for env_var, kwarg in _int_vars.items():
        if v := os.environ.get(env_var):
            try:
                kwargs[kwarg] = int(v)
            except ValueError:
                raise ValueError(
                    f"{env_var}={v!r} could not be converted to int"
                )
    _float_vars = {"S3_CONNECT_TIMEOUT": "connect_timeout", "S3_READ_TIMEOUT": "read_timeout"}
    for env_var, kwarg in _float_vars.items():
        if v := os.environ.get(env_var):
            try:
                kwargs[kwarg] = float(v)
            except ValueError:
                raise ValueError(
                    f"{env_var}={v!r} could not be converted to float"
                )
    return kwargs


def _ensure_s3_available() -> tuple[Any, Any]:
    """Import and return (S3Backend, S3Config) from deepagents-backends.

    Raises ImportError with an install hint if the package is absent.
    """
    try:
        from deepagents_backends import S3Backend, S3Config
        return S3Backend, S3Config
    except ImportError as exc:
        raise ImportError(
            "S3 backend requires deepagents-backends. "
            "Install it with: pip install deep-loom-kit[s3]"
        ) from exc


def _build_s3_backend_with_prefix(cfg: Any, prefix: str | None) -> Any:
    """Build an S3Backend with an overridden prefix (used for isolation)."""
    S3Backend, S3Config = _ensure_s3_available()
    s3_config = S3Config(bucket=cfg.bucket, prefix=prefix, **_resolve_s3_env_kwargs())
    return S3Backend(s3_config)


def _make_s3_factory(cfg: Any, isolation: Any = None) -> Any:
    """Return a (ToolRuntime) -> S3Backend factory.

    No-isolation: instance created eagerly once (preserves single-instance semantics).
    Isolation: new instance per call (prefix changes per isolation key).
    """
    _needs_isolation = isolation is not None and isolation.mode != "none"

    if not _needs_isolation:
        # Eager capture — cfg.prefix is static; use _build_s3_backend_with_prefix
        # to keep a single construction path.
        _instance = _build_s3_backend_with_prefix(cfg, cfg.prefix)

        def factory_simple(rt: Any) -> Any:
            return _instance

        return factory_simple

    def factory_isolated(rt: Any) -> Any:
        key = _resolve_isolation_key(isolation, rt)
        parts = [cfg.prefix] if cfg.prefix else []
        parts.append(key)
        return _build_s3_backend_with_prefix(cfg, "/".join(parts))

    return factory_isolated
