"""Composite backend builder — routes + default backend factory."""

from __future__ import annotations

import os
import warnings
from pathlib import Path
from typing import Any

from langgraph.store.memory import InMemoryStore

from ._isolation import _resolve_isolation_key
from ._s3 import _build_s3_backend_with_prefix, _resolve_s3_env_kwargs
from ._simple import _resolve_root


def _join_s3_prefix(*parts: str | None) -> str:
    """Join non-empty S3 prefix segments with '/'."""
    return "/".join(p for p in parts if p)


def _build_fs_root_for_route(
    base: str | None,
    isolation_key: str | None,
    route_name: str,
    include_route: bool,
    require_base_for_bare_route: bool = True,
) -> str | None:
    """Build a filesystem root path from isolation + route components.

    Ordering: ``{base}/{isolation_key}/{route_name}`` (each only when applicable).

    Args:
        base: Base directory (may be ``None``).
        isolation_key: Resolved isolation key, or ``None``.
        route_name: Route name (prefix stripped of slashes).
        include_route: Whether to append ``route_name`` when isolation is active.
        require_base_for_bare_route: When ``True`` (default, string-shorthand paths),
            ``route_name`` is only appended without isolation if ``base`` is set.
            When ``False`` (structured-config paths), ``route_name`` is always
            appended when no isolation is active.
    """
    parts = [base] if base else []
    if isolation_key:
        parts.append(isolation_key)
        if include_route and route_name:
            parts.append(route_name)
    elif include_route and route_name and (base or not require_base_for_bare_route):
        parts.append(route_name)
    return "/".join(parts) if parts else None


def _build_route_instance(
    btype: str,
    prefix: str,
    root_dir: Path | None,
    rt: Any,
    isolation_key: str | None = None,
) -> Any:
    """Build a single backend instance for a given type, route prefix, and runtime.

    String-shorthand composite routes always include the route name in the path.
    Users needing ``include_route=False`` must use a structured BackendConfig object.

    Backend classes are imported lazily from ``deep_loom_kit.backends`` so that
    tests can patch them.

    Note: string-shorthand composite routes (e.g. ``filesystem``, ``local_shell``)
    always use ``virtual_mode=True`` and the default ``LocalShellBackend`` settings
    (``timeout``, ``max_output_bytes``, ``env``, ``inherit_env``). Users needing
    custom values must use a structured ``LocalShellBackendConfig`` route object.
    """
    from deep_loom_kit.backends import (  # late imports — patchable by tests
        FilesystemBackend,
        LocalShellBackend,
        StateBackend,
        StoreBackend,
    )

    route_name = prefix.strip("/")  # "/skills/" → "skills"
    if btype in ("memory", "store"):
        if isolation_key:
            ns: tuple = (
                ("filesystem", isolation_key, route_name)
                if route_name
                else ("filesystem", isolation_key)
            )
            return StoreBackend(rt, namespace=ns)
        return StoreBackend(rt)
    elif btype == "filesystem":
        base = str(root_dir) if root_dir else None
        return FilesystemBackend(
            root_dir=_build_fs_root_for_route(base, isolation_key, route_name, True),
            virtual_mode=True,
        )
    elif btype == "local_shell":
        # Note: composite route strings carry no extra config, so timeout/max_output_bytes/
        # env/inherit_env always use LocalShellBackend defaults in this path.
        base = str(root_dir) if root_dir else None
        ls_root = _build_fs_root_for_route(base, isolation_key, route_name, True)
        if ls_root:
            Path(ls_root).mkdir(parents=True, exist_ok=True)
        return LocalShellBackend(
            root_dir=ls_root,
            virtual_mode=True,
        )
    elif btype == "s3":
        bucket = os.environ.get("S3_BUCKET")
        if not bucket:
            raise RuntimeError(
                "S3 backend requires the S3_BUCKET environment variable to be set. "
                "Set S3_BUCKET or use a structured route config with 'bucket:'."
            )
        try:
            from deepagents_backends import S3Backend, S3Config
        except ImportError as exc:
            raise ImportError(
                "S3 backend requires deepagents-backends. "
                "Install it with: pip install deep-loom-kit[s3]"
            ) from exc
        s3_prefix = _join_s3_prefix(isolation_key, route_name) or None
        return S3Backend(S3Config(bucket=bucket, prefix=s3_prefix, **_resolve_s3_env_kwargs()))
    else:  # "state" or unrecognised
        if btype != "state":
            warnings.warn(
                f"Unrecognised composite backend type {btype!r}; falling back to StateBackend.",
                stacklevel=2,
            )
        return StateBackend(rt)


def _build_route_from_config(
    cfg: Any,
    prefix: str,
    root_dir: Path | None,
    rt: Any,
    parent_isolation_key: str | None,
) -> Any:
    """Build a single backend instance from a full BackendConfig for a composite route.

    Per-route ``cfg.isolation`` takes precedence over *parent_isolation_key*.
    ``include_route`` is always read from the backend config object itself.

    Backend classes are imported lazily from ``deep_loom_kit.backends`` so that
    tests can patch them.
    """
    from deep_loom_kit.backends import (  # late imports — patchable by tests
        FilesystemBackend,
        LocalShellBackend,
        StateBackend,
        StoreBackend,
    )
    from ..schema import (
        FilesystemBackendConfig,
        LocalShellBackendConfig,
        S3BackendConfig,
        StoreBackendConfig,
    )

    route_name = prefix.strip("/")
    isolation_key = parent_isolation_key
    include_route = getattr(cfg, "include_route", True)
    cfg_isolation = getattr(cfg, "isolation", None)
    if cfg_isolation is not None and cfg_isolation.mode != "none":
        isolation_key = _resolve_isolation_key(cfg_isolation, rt)

    if isinstance(cfg, StoreBackendConfig):
        if isolation_key:
            ns: tuple = (
                ("filesystem", isolation_key, route_name)
                if (include_route and route_name)
                else ("filesystem", isolation_key)
            )
            return StoreBackend(rt, namespace=ns)
        return StoreBackend(rt)

    if isinstance(cfg, FilesystemBackendConfig):
        base_root = _resolve_root(cfg.root_dir, root_dir)
        base = str(base_root) if base_root else None
        fs_root = _build_fs_root_for_route(base, isolation_key, route_name, include_route, require_base_for_bare_route=False)
        return FilesystemBackend(root_dir=fs_root, virtual_mode=cfg.virtual_mode)

    if isinstance(cfg, LocalShellBackendConfig):
        base_root = _resolve_root(cfg.root_dir, root_dir)
        base = str(base_root) if base_root else None
        ls_root = _build_fs_root_for_route(base, isolation_key, route_name, include_route, require_base_for_bare_route=False)
        if ls_root:
            Path(ls_root).mkdir(parents=True, exist_ok=True)
        return LocalShellBackend(
            root_dir=ls_root,
            virtual_mode=cfg.virtual_mode,
            timeout=cfg.timeout,
            max_output_bytes=cfg.max_output_bytes,
            env=cfg.env,
            inherit_env=cfg.inherit_env,
        )

    if isinstance(cfg, S3BackendConfig):
        return _build_s3_backend_with_prefix(
            cfg,
            _join_s3_prefix(
                cfg.prefix or None,
                isolation_key,
                route_name if (include_route and route_name) else None,
            ) or None,
        )

    # StateBackendConfig or unknown
    return StateBackend(rt)


def _build_composite_backend(
    cb: Any,
    root_dir: Path | None,
) -> tuple[Any, Any]:
    """Build a CompositeBackend factory from a CompositeBackendConfig."""
    from ..schema import StateBackendConfig, StoreBackendConfig

    _default = cb.default  # str shorthand or full BackendConfig object

    # Eager S3_BUCKET check — fail fast if any string-shorthand 's3' route is present
    # but the required environment variable is missing.
    s3_bucket = os.environ.get("S3_BUCKET")
    has_s3_string_route = (
        (isinstance(_default, str) and _default.lower() == "s3")
        or any(isinstance(v, str) and v.lower() == "s3" for v in cb.routes.values())
    )
    if has_s3_string_route and not s3_bucket:
        raise RuntimeError(
            "One or more composite routes use the 's3' string shorthand but "
            "S3_BUCKET environment variable is not set. "
            "Set S3_BUCKET or use a structured route config with 'bucket:'."
        )

    route_map: dict[str, Any] = {}  # values are str (lowercased) or BackendConfig
    need_store = (
        (isinstance(_default, str) and _default.lower() in ("memory", "store"))
        or isinstance(_default, StoreBackendConfig)
    )

    for route_name, route_val in cb.routes.items():
        if not route_name.strip("/"):
            raise ValueError(
                f"Composite route key {route_name!r} is empty after stripping slashes."
            )
        prefix = f"/{route_name.strip('/')}/"
        if isinstance(route_val, str):
            route_map[prefix] = route_val.lower()
            if route_val.lower() in ("memory", "store"):
                need_store = True
        else:
            route_map[prefix] = route_val
            if isinstance(route_val, StoreBackendConfig):
                need_store = True

    default_is_state = (
        isinstance(_default, str) and _default.lower() == "state"
    ) or isinstance(_default, StateBackendConfig)
    if not route_map and default_is_state and not (cb.isolation and cb.isolation.mode != "none"):
        return None, None

    store = InMemoryStore() if need_store else None
    _route_map = route_map
    _root_dir = root_dir
    _default_backend_spec = _default  # str or BackendConfig
    _isolation = cb.isolation if cb.isolation and cb.isolation.mode != "none" else None

    def backend_factory(rt: Any) -> Any:
        from deep_loom_kit.backends import CompositeBackend  # late import — patchable by tests

        isolation_key: str | None = None
        if _isolation:
            isolation_key = _resolve_isolation_key(_isolation, rt)
        built_routes: dict[str, Any] = {}
        for prefix, route_val in _route_map.items():
            if isinstance(route_val, str):
                built_routes[prefix] = _build_route_instance(route_val, prefix, _root_dir, rt, isolation_key)
            else:
                built_routes[prefix] = _build_route_from_config(route_val, prefix, _root_dir, rt, isolation_key)
        if isinstance(_default_backend_spec, str):
            default_backend = _build_route_instance(_default_backend_spec, "/", _root_dir, rt, isolation_key)
        else:
            default_backend = _build_route_from_config(_default_backend_spec, "/", _root_dir, rt, isolation_key)
        return CompositeBackend(default=default_backend, routes=built_routes)

    return backend_factory, store
