"""Isolation key resolution and per-backend isolation factory helpers."""

from __future__ import annotations

from typing import Any


def _validate_isolation_key(key: str) -> str:
    """Validate that *key* is safe to use as a path segment.

    Raises ``RuntimeError`` if *key*:
    - is empty (would create double-slashes in paths)
    - is ``.`` or ``..`` (directory traversal)
    - contains null bytes
    """
    if not key:
        raise RuntimeError("Isolation key must not be empty")
    segments = key.replace("\\", "/").split("/")
    if any(s in (".", "..") for s in segments):
        raise RuntimeError(
            f"Isolation key {key!r} contains a path separator or traversal sequence"
        )
    if "\x00" in key:
        raise RuntimeError(
            f"Isolation key {key!r} contains null bytes"
        )
    return key


def _resolve_isolation_key(isolation: Any, rt: Any) -> str:
    """Resolve the isolation key from the Runtime object based on isolation mode.

    For ``thread_id`` mode, reads the thread_id from the LangGraph config context
    variable via ``get_config()``.  For ``context`` mode, reads the named attribute
    directly from ``rt.context``.

    NOTE: ``get_config`` is imported lazily from ``deep_loom_kit.backends`` so that
    tests can patch ``deep_loom_kit.backends.get_config`` and have it take effect.
    """
    from deep_loom_kit.backends import get_config  # late import — patchable by tests

    if isolation.mode == "thread_id":
        cfg = get_config()
        tid = cfg.get("configurable", {}).get("thread_id")
        if not tid:
            raise RuntimeError("isolation mode 'thread_id' requires a thread_id in runtime config")
        return _validate_isolation_key(tid)
    elif isolation.mode == "context":
        ctx = getattr(rt, "context", None)
        if ctx is None:
            raise RuntimeError("isolation mode 'context' requires a context object at invoke time")
        if not hasattr(ctx, isolation.variable):
            raise RuntimeError(f"Context has no attribute '{isolation.variable}'")
        val = getattr(ctx, isolation.variable)
        if not isinstance(val, (str, int, float)):
            raise RuntimeError(
                f"Isolation key attribute '{isolation.variable}' must be str/int/float, "
                f"got {type(val).__name__!r}"
            )
        return _validate_isolation_key(str(val))
    return ""  # mode == "none"


def _make_path_factory(
    btype: str,
    base_root: str | None,
    virtual_mode: bool,
    isolation: Any = None,
    extra_kwargs: dict | None = None,
) -> Any:
    """Return a (ToolRuntime) -> backend factory for Filesystem or LocalShell.

    No-isolation: instance created eagerly once, reused across all calls.
    Isolation: new instance per call (root_dir changes per thread/context key).
    """
    from deep_loom_kit.backends import FilesystemBackend, LocalShellBackend  # late import

    _extra = extra_kwargs or {}
    _needs_isolation = isolation is not None and isolation.mode != "none"

    if not _needs_isolation:
        if btype == "filesystem":
            _instance = FilesystemBackend(root_dir=base_root, virtual_mode=virtual_mode)
        else:
            _instance = LocalShellBackend(root_dir=base_root, virtual_mode=virtual_mode, **_extra)

        def factory_simple(rt: Any) -> Any:
            return _instance

        return factory_simple

    def factory_isolated(rt: Any) -> Any:
        key = _resolve_isolation_key(isolation, rt)
        parts = [base_root] if base_root else []
        parts.append(key)
        isolated = "/".join(parts)
        if btype == "filesystem":
            return FilesystemBackend(root_dir=isolated, virtual_mode=virtual_mode)
        else:
            return LocalShellBackend(root_dir=isolated, virtual_mode=virtual_mode, **_extra)

    return factory_isolated


def _make_store_factory(isolation: Any = None) -> Any:
    """Return a (ToolRuntime) -> StoreBackend factory.

    No-isolation: StoreBackend(rt) with no namespace.
    Isolation: StoreBackend(rt, namespace=("filesystem", key)) — 2-tuple, no route name.
    """
    from deep_loom_kit.backends import StoreBackend  # late import

    _needs_isolation = isolation is not None and isolation.mode != "none"

    def factory(rt: Any) -> Any:
        if _needs_isolation:
            key = _resolve_isolation_key(isolation, rt)
            return StoreBackend(rt, namespace=("filesystem", key))
        return StoreBackend(rt)

    return factory
