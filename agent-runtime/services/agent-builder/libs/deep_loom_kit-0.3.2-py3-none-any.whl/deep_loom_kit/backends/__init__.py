"""Backend mapping from YAML config to deepagents backend instances.

This is the public surface of the ``deep_loom_kit.backends`` package.

The backend classes imported here (``FilesystemBackend``, ``StateBackend``, etc.)
and ``get_config`` are imported at module level so that tests can patch them via
``patch("deep_loom_kit.backends.XYZ")``.  Submodules perform *lazy* imports from
this module inside their function bodies to pick up any active patches at call time.
"""

from __future__ import annotations

import warnings
from pathlib import Path
from typing import Any

# ── Patchable names ────────────────────────────────────────────────────────────
# These must be imported at module level so that ``patch("deep_loom_kit.backends.X")``
# replaces the name here, and submodule functions that do
# ``from deep_loom_kit.backends import X`` at call time pick up the mock.

from deepagents.backends import (
    CompositeBackend,
    FilesystemBackend,
    LocalShellBackend,
    StateBackend,
    StoreBackend,
)
from langgraph.config import get_config
from langgraph.store.memory import InMemoryStore

# ── Schema ─────────────────────────────────────────────────────────────────────
from ..schema import AgentConfig, ServiceStoreConfig  # noqa: F401 (re-export for type hints)

# ── Submodule functions ────────────────────────────────────────────────────────
from ._isolation import (
    _make_path_factory,
    _make_store_factory,
    _resolve_isolation_key,
)
from ._s3 import (
    _build_s3_backend_with_prefix,
    _make_s3_factory,
    _resolve_s3_env_kwargs,
)
from ._simple import _build_simple_backend, _resolve_root
from ._composite import _build_composite_backend, _build_route_from_config, _build_route_instance
from ._store import _build_postgres_store, build_store
from ._skills import build_skills_backend_factory

# ── External file access (non-patchable data types + helpers) ─────────────────
from deepagents.backends.protocol import FileDownloadResponse, FileInfo, FileUploadResponse, WriteResult
from ._external import _build_composite, _build_simple, _StateFileAccessor, _StoreFileAccessor


def build_backend(
    agent_config: AgentConfig,
    root_dir: Path | None = None,
) -> tuple[Any, InMemoryStore | None]:
    """Build a backend factory and optional store from an agent config.

    Returns a ``(backend_or_factory, store)`` tuple.

    - ``factory`` is a callable ``(ToolRuntime) -> BackendProtocol`` suitable for
      passing as ``backend=`` to ``create_deep_agent``, or ``None`` (deepagents
      uses its default ``StateBackend``).
    - ``store`` is an :class:`InMemoryStore` instance to pass as ``store=``
      when the config includes memory/store routes.  ``None`` means no store.

    Backend resolution order
    ------------------------
    1. ``composite_backend`` takes precedence over ``backend`` when both are set.
    2. ``backend`` (simple) is used when only it is set.
    3. Neither set → ``None`` (deepagents default ``StateBackend``).

    Route-to-backend mapping (composite)
    -------------------------------------
    - ``"memory"`` / ``"store"``  → :class:`StoreBackend`  (requires store)
    - ``"filesystem"``            → :class:`FilesystemBackend` (virtual mode)
    - ``"local_shell"``           → :class:`LocalShellBackend` (virtual mode)
    - absent routes               → ``None`` (default backend)
    """
    # --- Composite backend (takes precedence) ---
    if agent_config.composite_backend:
        if agent_config.backend:
            warnings.warn(
                f"Agent '{agent_config.name}' has both 'backend' and 'composite_backend' set. "
                "'composite_backend' takes precedence; 'backend' will be ignored.",
                stacklevel=2,
            )
        return _build_composite_backend(agent_config.composite_backend, root_dir)

    # --- Simple top-level backend ---
    if agent_config.backend:
        return _build_simple_backend(agent_config.backend, root_dir)

    return None, None


__all__ = [
    # public API
    "build_backend",
    "build_store",
    "build_skills_backend_factory",
    # re-exported for tests / internal use
    "_resolve_isolation_key",
    "_build_s3_backend_with_prefix",
    "_build_postgres_store",
    "_resolve_root",
    "_build_simple_backend",
    "_build_composite_backend",
    "_build_route_instance",
    "_build_route_from_config",
    "_make_path_factory",
    "_make_store_factory",
    "_make_s3_factory",
    "_resolve_s3_env_kwargs",
    # patchable backend classes
    "CompositeBackend",
    "FilesystemBackend",
    "LocalShellBackend",
    "StateBackend",
    "StoreBackend",
    "get_config",
    "InMemoryStore",
    # external file access
    "_build_simple",
    "_build_composite",
    "_StateFileAccessor",
    "_StoreFileAccessor",
    "FileDownloadResponse",
    "FileInfo",
    "FileUploadResponse",
    "WriteResult",
]
