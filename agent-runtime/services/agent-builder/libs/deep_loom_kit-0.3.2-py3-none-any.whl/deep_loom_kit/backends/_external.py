"""External (out-of-graph) file access helpers for AgentRuntime.

Provides backend reconstruction for list_files / read_file / download_files /
upload_files calls that happen outside LangGraph graph execution.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from deepagents.backends.protocol import (
    BackendProtocol,
    FileDownloadResponse,
    FileInfo,
    FileUploadResponse,
    GrepMatch,
    WriteResult,
)
from deepagents.backends.utils import (
    _glob_search_files,
    create_file_data,
    file_data_to_string,
    format_read_response,
    grep_matches_from_files,
)

from ._isolation import _validate_isolation_key

__all__ = [
    "_resolve_isolation_key_external",
    "_StateFileAccessor",
    "_StoreFileAccessor",
    "_build_simple",
    "_build_route_for_external",
    "_build_composite",
]


# ---------------------------------------------------------------------------
# Isolation key resolution (external variant — no get_config())
# ---------------------------------------------------------------------------


def _resolve_isolation_key_external(
    isolation: Any,
    thread_id: str,
    context: Any,
) -> str:
    """Resolve isolation key from thread_id/context instead of LangGraph config.

    Mirrors _resolve_isolation_key() but safe to call outside graph execution.
    Returns "" for mode=="none".
    """
    if isolation.mode == "thread_id":
        if not thread_id:
            raise RuntimeError("isolation mode 'thread_id' requires thread_id")
        return _validate_isolation_key(thread_id)
    elif isolation.mode == "context":
        if context is None:
            raise RuntimeError("isolation mode 'context' requires a context object")
        if not hasattr(context, isolation.variable):
            raise RuntimeError(f"Context has no attribute '{isolation.variable}'")
        val = getattr(context, isolation.variable)
        if not isinstance(val, (str, int, float)):
            raise RuntimeError(
                f"Isolation key attribute '{isolation.variable}' must be str/int/float, "
                f"got {type(val).__name__!r}"
            )
        return _validate_isolation_key(str(val))
    return ""  # mode == "none"


# ---------------------------------------------------------------------------
# _StateFileAccessor — read-only view of files dict from StateSnapshot
# ---------------------------------------------------------------------------


class _StateFileAccessor(BackendProtocol):
    """Read-only BackendProtocol backed by a files dict from get_state()."""

    def __init__(self, files: dict) -> None:
        self._files = files

    # --- read methods ---

    def ls_info(self, path: str) -> list[FileInfo]:
        infos: list[FileInfo] = []
        subdirs: set[str] = set()
        normalized_path = path if path.endswith("/") else path + "/"
        for k, fd in self._files.items():
            if not k.startswith(normalized_path):
                continue
            relative = k[len(normalized_path):]
            if "/" in relative:
                subdir_name = relative.split("/")[0]
                subdirs.add(normalized_path + subdir_name + "/")
                continue
            size = len("\n".join(fd.get("content", [])))
            infos.append({"path": k, "is_dir": False, "size": int(size), "modified_at": fd.get("modified_at", "")})
        infos.extend(FileInfo(path=subdir, is_dir=True, size=0, modified_at="") for subdir in sorted(subdirs))
        infos.sort(key=lambda x: x.get("path", ""))
        return infos

    def read(self, file_path: str, offset: int = 0, limit: int = 2000) -> str:
        fd = self._files.get(file_path)
        if fd is None:
            return f"Error: File '{file_path}' not found"
        return format_read_response(fd, offset, limit)

    def grep_raw(
        self,
        pattern: str,
        path: str | None = None,
        glob: str | None = None,
    ) -> list[GrepMatch] | str:
        return grep_matches_from_files(self._files, pattern, path if path is not None else "/", glob)

    def glob_info(self, pattern: str, path: str = "/") -> list[FileInfo]:
        result = _glob_search_files(self._files, pattern, path)
        if result == "No files found":
            return []
        paths = result.split("\n")
        infos: list[FileInfo] = []
        for p in paths:
            fd = self._files.get(p)
            size = len("\n".join(fd.get("content", []))) if fd else 0
            infos.append({
                "path": p,
                "is_dir": False,
                "size": int(size),
                "modified_at": fd.get("modified_at", "") if fd else "",
            })
        return infos

    def download_files(self, paths: list[str]) -> list[FileDownloadResponse]:
        responses: list[FileDownloadResponse] = []
        for path in paths:
            fd = self._files.get(path)
            if fd is None:
                responses.append(FileDownloadResponse(path=path, content=None, error="file_not_found"))
                continue
            content_str = file_data_to_string(fd)
            responses.append(FileDownloadResponse(path=path, content=content_str.encode("utf-8"), error=None))
        return responses

    # --- write stubs ---

    def write(self, file_path: str, content: str) -> Any:
        raise NotImplementedError("_StateFileAccessor is read-only")

    def edit(self, file_path: str, old_string: str, new_string: str, replace_all: bool = False) -> Any:
        raise NotImplementedError("_StateFileAccessor is read-only")

    def upload_files(self, files: list[tuple[str, bytes]]) -> Any:
        raise NotImplementedError("_StateFileAccessor is read-only")


# ---------------------------------------------------------------------------
# _StoreFileAccessor — view of store + namespace (read + upload_files/aupload_files)
# ---------------------------------------------------------------------------


class _StoreFileAccessor(BackendProtocol):
    """BackendProtocol backed by a (store, namespace) pair. Supports upload_files / aupload_files."""

    def __init__(self, store: Any, *, namespace: tuple) -> None:
        self._store = store
        self._namespace = namespace

    @staticmethod
    def _item_to_fd(item: Any) -> dict:
        return {
            "content": item.value["content"],
            "created_at": item.value["created_at"],
            "modified_at": item.value["modified_at"],
        }

    def _all_items(self) -> list[Any]:
        all_items: list[Any] = []
        offset = 0
        page_size = 100
        while True:
            page = self._store.search(self._namespace, limit=page_size, offset=offset)
            if not page:
                break
            all_items.extend(page)
            if len(page) < page_size:
                break
            offset += page_size
        return all_items

    def _all_files(self) -> dict:
        files: dict = {}
        for item in self._all_items():
            try:
                files[item.key] = self._item_to_fd(item)
            except (KeyError, TypeError, ValueError):
                continue
        return files

    # --- read methods ---

    def ls_info(self, path: str) -> list[FileInfo]:
        infos: list[FileInfo] = []
        subdirs: set[str] = set()
        normalized_path = path if path.endswith("/") else path + "/"
        for item in self._all_items():
            k = str(item.key)
            if not k.startswith(normalized_path):
                continue
            relative = k[len(normalized_path):]
            if "/" in relative:
                subdir_name = relative.split("/")[0]
                subdirs.add(normalized_path + subdir_name + "/")
                continue
            try:
                fd = self._item_to_fd(item)
            except (KeyError, TypeError, ValueError):
                continue
            size = len("\n".join(fd.get("content", [])))
            infos.append({"path": k, "is_dir": False, "size": int(size), "modified_at": fd.get("modified_at", "")})
        infos.extend(FileInfo(path=subdir, is_dir=True, size=0, modified_at="") for subdir in sorted(subdirs))
        infos.sort(key=lambda x: x.get("path", ""))
        return infos

    def read(self, file_path: str, offset: int = 0, limit: int = 2000) -> str:
        item = self._store.get(self._namespace, file_path)
        if item is None:
            return f"Error: File '{file_path}' not found"
        try:
            fd = self._item_to_fd(item)
        except (KeyError, TypeError, ValueError) as e:
            return f"Error: {e}"
        return format_read_response(fd, offset, limit)

    def grep_raw(
        self,
        pattern: str,
        path: str | None = None,
        glob: str | None = None,
    ) -> list[GrepMatch] | str:
        return grep_matches_from_files(self._all_files(), pattern, path if path is not None else "/", glob)

    def glob_info(self, pattern: str, path: str = "/") -> list[FileInfo]:
        files = self._all_files()
        result = _glob_search_files(files, pattern, path)
        if result == "No files found":
            return []
        paths = result.split("\n")
        infos: list[FileInfo] = []
        for p in paths:
            fd = files.get(p)
            size = len("\n".join(fd.get("content", []))) if fd else 0
            infos.append({
                "path": p,
                "is_dir": False,
                "size": int(size),
                "modified_at": fd.get("modified_at", "") if fd else "",
            })
        return infos

    def download_files(self, paths: list[str]) -> list[FileDownloadResponse]:
        responses: list[FileDownloadResponse] = []
        for path in paths:
            item = self._store.get(self._namespace, path)
            if item is None:
                responses.append(FileDownloadResponse(path=path, content=None, error="file_not_found"))
                continue
            try:
                fd = self._item_to_fd(item)
            except (KeyError, TypeError, ValueError):
                responses.append(FileDownloadResponse(path=path, content=None, error="file_not_found"))
                continue
            content_str = file_data_to_string(fd)
            responses.append(FileDownloadResponse(path=path, content=content_str.encode("utf-8"), error=None))
        return responses

    # --- write methods ---

    def upload_files(self, files: list[tuple[str, bytes]]) -> list[FileUploadResponse]:
        results: list[FileUploadResponse] = []
        for path, content in files:
            try:
                text = content.decode("utf-8", errors="replace")
                self._store.put(self._namespace, path, create_file_data(text))
                results.append(FileUploadResponse(path=path, error=None))
            except Exception as exc:
                results.append(FileUploadResponse(path=path, error=str(exc)))
        return results

    async def aupload_files(self, files: list[tuple[str, bytes]]) -> list[FileUploadResponse]:
        results: list[FileUploadResponse] = []
        for path, content in files:
            try:
                text = content.decode("utf-8", errors="replace")
                await self._store.aput(self._namespace, path, create_file_data(text))
                results.append(FileUploadResponse(path=path, error=None))
            except Exception as exc:
                results.append(FileUploadResponse(path=path, error=str(exc)))
        return results

    def write(self, file_path: str, content: str) -> WriteResult:
        try:
            self._store.put(self._namespace, file_path, create_file_data(content))
            return WriteResult(error=None, path=file_path, files_update=None)
        except Exception as exc:
            return WriteResult(error=str(exc), path=file_path, files_update=None)

    def edit(self, file_path: str, old_string: str, new_string: str, replace_all: bool = False) -> Any:
        raise NotImplementedError("_StoreFileAccessor does not support edit()")


# ---------------------------------------------------------------------------
# _build_simple — reconstruct isolated simple backend outside graph
# ---------------------------------------------------------------------------


def _build_simple(rt: Any, thread_id: str, context: Any) -> Any:
    """Reconstruct an isolated simple backend from rt._agent_config.backend.

    Only called when has_isolation=True. Returns a FilesystemBackend, _StoreFileAccessor, or S3Backend depending on the config.
    """
    from deep_loom_kit.backends import FilesystemBackend  # late import — patchable
    from ._simple import _resolve_root
    from ..schema import FilesystemBackendConfig, LocalShellBackendConfig, S3BackendConfig, StoreBackendConfig

    cfg = rt._agent_config.backend
    if cfg is None:
        return _StateFileAccessor({})

    if isinstance(cfg, (FilesystemBackendConfig, LocalShellBackendConfig)):
        key = _resolve_isolation_key_external(cfg.isolation, thread_id, context)
        root = _resolve_root(cfg.root_dir, rt._root_dir)
        root_str = str(root) if root else None
        parts = [root_str] if root_str else []
        parts.append(key)
        isolated_root = "/".join(parts) if parts else None
        result = FilesystemBackend(root_dir=isolated_root, virtual_mode=cfg.virtual_mode)

    elif isinstance(cfg, StoreBackendConfig):
        key = _resolve_isolation_key_external(cfg.isolation, thread_id, context)
        store = rt._agent.store
        if store is None:
            raise RuntimeError("isolation mode 'store' requires a store")
        result = _StoreFileAccessor(store, namespace=("filesystem", key))

    elif isinstance(cfg, S3BackendConfig):
        from ._s3 import _build_s3_backend_with_prefix
        key = _resolve_isolation_key_external(cfg.isolation, thread_id, context)
        prefix = "/".join(p for p in [cfg.prefix or None, key] if p) or None
        result = _build_s3_backend_with_prefix(cfg, prefix)

    else:
        result = _StateFileAccessor({})

    if rt._skills_dir is not None:
        from deep_loom_kit.backends._skills import _SkillsProxy
        skills_fsb = FilesystemBackend(root_dir=str(rt._skills_dir), virtual_mode=True)
        result = _SkillsProxy(result, skills_fsb)

    return result


# ---------------------------------------------------------------------------
# _build_route_for_external — per-route backend for composite external access
# ---------------------------------------------------------------------------


def _build_route_for_external(
    cfg: Any,
    prefix: str,
    root_dir: Path | None,
    agent: Any,
    thread_id: str,
    context: Any,
    parent_isolation_key: str | None,
    snapshot: Any,
) -> Any:
    """Build a single backend instance for a composite route (external, out-of-graph).

    Mirrors _build_route_from_config but uses _resolve_isolation_key_external,
    _StoreFileAccessor, and _StateFileAccessor instead of live runtime variants.
    """
    from deep_loom_kit.backends import FilesystemBackend, LocalShellBackend, StoreBackend  # noqa: F401  # pyright: ignore[reportUnusedImport]  # late — patchability parity
    from ..schema import FilesystemBackendConfig, LocalShellBackendConfig, S3BackendConfig, StateBackendConfig, StoreBackendConfig
    from ._s3 import _build_s3_backend_with_prefix
    from ._simple import _resolve_root
    from ._composite import _build_fs_root_for_route, _join_s3_prefix

    route_name = prefix.strip("/")
    isolation_key = parent_isolation_key
    include_route = getattr(cfg, "include_route", True)
    cfg_isolation = getattr(cfg, "isolation", None)
    if cfg_isolation is not None and cfg_isolation.mode != "none":
        isolation_key = _resolve_isolation_key_external(cfg_isolation, thread_id, context)

    if isinstance(cfg, StoreBackendConfig):
        store = agent.store
        if store is None:
            raise RuntimeError("composite store route requires a store")
        if isolation_key:
            ns = ("filesystem", isolation_key, route_name) if (include_route and route_name) else ("filesystem", isolation_key)
        else:
            ns = ("filesystem",)
        return _StoreFileAccessor(store, namespace=ns)

    if isinstance(cfg, StateBackendConfig):
        return _StateFileAccessor(snapshot.values.get("files", {}))

    if isinstance(cfg, (FilesystemBackendConfig, LocalShellBackendConfig)):
        base_root = _resolve_root(cfg.root_dir, root_dir)
        base = str(base_root) if base_root else None
        fs_root = _build_fs_root_for_route(base, isolation_key, route_name, include_route, require_base_for_bare_route=False)
        return FilesystemBackend(root_dir=fs_root, virtual_mode=cfg.virtual_mode)

    if isinstance(cfg, S3BackendConfig):
        return _build_s3_backend_with_prefix(
            cfg,
            _join_s3_prefix(cfg.prefix or None, isolation_key, route_name if (include_route and route_name) else None) or None,
        )

    return _StateFileAccessor(snapshot.values.get("files", {}))


# ---------------------------------------------------------------------------
# _build_composite — async composite backend reconstruction
# ---------------------------------------------------------------------------


async def _build_composite(rt: Any, thread_id: str, context: Any, **kwargs: Any) -> Any:
    """Build a CompositeBackend for external (out-of-graph) access.

    Mirrors the backend_factory closure in _build_composite_backend but:
    - Is async (pre-fetches the state snapshot)
    - Uses _StateFileAccessor for "state"-typed routes
    - Uses _build_route_for_external for BackendConfig routes
    - Applies skills proxy at top level only

    ``**kwargs`` are forwarded to ``rt.get_state()`` (e.g. ``checkpoint_id``,
    ``checkpoint_ns`` via ``config={"configurable": {...}}``).
    """
    from deep_loom_kit.backends import CompositeBackend, _build_route_instance  # late — patchable

    cb = rt._agent_config.composite_backend
    snapshot = await rt.get_state(thread_id, **kwargs)

    # normalise route_map
    route_map: dict[str, Any] = {}
    for route_name, route_val in cb.routes.items():
        prefix = f"/{route_name.strip('/')}/"
        route_map[prefix] = route_val.lower() if isinstance(route_val, str) else route_val

    # composite-level isolation key
    isolation_key: str | None = None
    if cb.isolation and cb.isolation.mode != "none":
        isolation_key = _resolve_isolation_key_external(cb.isolation, thread_id, context)

    # build routes
    built_routes: dict[str, Any] = {}
    for prefix, route_val in route_map.items():
        if isinstance(route_val, str):
            if route_val == "state":
                built_routes[prefix] = _StateFileAccessor(snapshot.values.get("files", {}))
            elif route_val in ("store", "memory"):
                store = rt._agent.store
                if store is None:
                    raise RuntimeError(
                        f"composite '{route_val}' route requires a store; agent was created without store="
                    )
                route_name = prefix.strip("/")
                ns: tuple = (
                    ("filesystem", isolation_key, route_name)
                    if (isolation_key and route_name)
                    else ("filesystem", isolation_key)
                    if isolation_key
                    else ("filesystem",)
                )
                built_routes[prefix] = _StoreFileAccessor(store, namespace=ns)
            else:
                # Only "filesystem", "local_shell", "s3" reach here — none use the `rt` arg
                # for backend construction (only "store"/"memory" do, and they are handled
                # above). Passing `rt._agent` (CompiledStateGraph) instead of a ToolRuntime
                # is safe because _build_route_instance only dereferences `rt` inside the
                # store/memory branch, which is unreachable from this code path.
                built_routes[prefix] = _build_route_instance(route_val, prefix, rt._root_dir, rt._agent, isolation_key)
        else:
            built_routes[prefix] = _build_route_for_external(
                route_val, prefix, rt._root_dir, rt._agent,
                thread_id, context, isolation_key, snapshot,
            )

    # default backend
    _default = cb.default
    if isinstance(_default, str):
        _default_lower = _default.lower()
        if _default_lower == "state":
            default_backend: Any = _StateFileAccessor(snapshot.values.get("files", {}))
        elif _default_lower in ("store", "memory"):
            _store = rt._agent.store
            if _store is None:
                raise RuntimeError(
                    f"composite '{_default_lower}' default requires a store; agent was created without store="
                )
            _ns: tuple = ("filesystem", isolation_key) if isolation_key else ("filesystem",)
            default_backend = _StoreFileAccessor(_store, namespace=_ns)
        else:
            # Same pre-filtering guarantee as for routes above: only "filesystem",
            # "local_shell", "s3" reach here; rt._agent is never used for store/memory.
            default_backend = _build_route_instance(_default_lower, "/", rt._root_dir, rt._agent, isolation_key)
    else:
        default_backend = _build_route_for_external(
            _default, "/", rt._root_dir, rt._agent,
            thread_id, context, isolation_key, snapshot,
        )

    result: Any = CompositeBackend(default=default_backend, routes=built_routes)

    # skills proxy at top level only
    if rt._skills_dir is not None:
        from deep_loom_kit.backends import FilesystemBackend  # late import — patchable
        from deep_loom_kit.backends._skills import _SkillsProxy
        skills_fsb = FilesystemBackend(root_dir=str(rt._skills_dir), virtual_mode=True)
        result = _SkillsProxy(result, skills_fsb)

    return result
