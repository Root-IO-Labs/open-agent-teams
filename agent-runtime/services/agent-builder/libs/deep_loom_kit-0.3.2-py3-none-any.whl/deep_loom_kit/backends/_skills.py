"""Skills backend proxy.

``_SkillsProxy`` routes ``/skills/*`` operations to a
``FilesystemBackend(root_dir=skills_dir)`` while delegating everything else to
the user's configured backend.  Path translation (stripping / re-adding the
``/skills`` prefix) is handled inline.  Write operations targeting ``/skills/``
paths raise ``PermissionError``.

``build_skills_backend_factory`` wraps any backend factory (or ``None`` for the
default StateBackend case) and returns a new callable suitable for passing as
``backend=`` to ``create_deep_agent``.
"""

from __future__ import annotations

import dataclasses
import functools
from pathlib import Path
from typing import Any


_SKILLS_PREFIX = "/skills"
_SKILLS_WRITE_ERROR = "Skills directory is read-only: write operations on /skills/ are not permitted."


def _fix_path(r: Any, path: str) -> Any:
    """Return *r* with the ``path`` field set to *path*.

    Handles dataclass (``dataclasses.replace``) and NamedTuple (``_replace``).
    Raises ``TypeError`` if neither works, so a wrong path never silently
    propagates to callers.
    """
    try:
        return dataclasses.replace(r, path=path)
    except (TypeError, AttributeError):
        pass
    if hasattr(r, "_replace"):
        try:
            return r._replace(path=path)
        except (TypeError, ValueError):
            pass
    raise TypeError(
        f"Cannot set path on {type(r).__name__!r}: "
        "not a dataclass or NamedTuple. Skills routing will not work."
    )


def _strip(path: str) -> str:
    """Strip ``/skills`` prefix; return ``/`` for bare ``/skills`` or ``/skills/``."""
    if path == _SKILLS_PREFIX:
        return "/"
    if path.startswith("/skills/"):
        return path[len(_SKILLS_PREFIX):] or "/"
    return path


def _add(item: Any) -> Any:
    """Re-add ``/skills`` prefix to a dict's ``"path"`` key."""
    if isinstance(item, dict) and "path" in item:
        return {**item, "path": _SKILLS_PREFIX + item["path"]}
    return item


def _is_root(path: str) -> bool:
    """Return True only for the two canonical root paths: '' and '/'."""
    return path == "" or path == "/"


def _make_skills_dir_entry(sb: Any) -> dict:
    """Build a ``/skills/`` directory entry for root listings.

    Calls ``sb.ls_info("")`` to borrow ``modified_at`` from the first result.
    Falls back to ``""`` if the skills dir is empty or the key is absent.
    Errors from ``sb.ls_info`` propagate — no silent swallowing.
    """
    entries = sb.ls_info("")
    modified_at = entries[0].get("modified_at", "") if entries else ""
    return {"path": "/skills/", "is_dir": True, "size": 0, "modified_at": modified_at}


async def _amake_skills_dir_entry(sb: Any) -> dict:
    """Async equivalent of :func:`_make_skills_dir_entry`."""
    entries = await sb.als_info("")
    modified_at = entries[0].get("modified_at", "") if entries else ""
    return {"path": "/skills/", "is_dir": True, "size": 0, "modified_at": modified_at}


def _ls_merge(base: list[Any], entry: dict) -> list[Any]:
    """Merge a skills directory entry into a root ``ls_info`` result.

    Filters any existing ``/skills`` or ``/skills/`` entry from *base*
    (replace-not-duplicate), then appends *entry*.
    """
    filtered = [e for e in base if e.get("path", "").rstrip("/") != "/skills"]
    return filtered + [entry]


def _glob_merge(base: list[Any], sb: Any, pattern: str) -> list[Any]:
    """Merge skills backend results into a root ``glob_info`` result.

    Always injects the ``/skills/`` container entry.
    For recursive patterns (those containing ``**``), also queries *sb* and
    re-adds the ``/skills`` prefix to each result via :func:`_add`.
    Any ``/skills/``-prefixed entries already in *base* are removed first
    (defensive dedup — the base backend should never have them in practice).
    """
    filtered = [e for e in base if not e.get("path", "").startswith("/skills/")]
    container = _make_skills_dir_entry(sb)
    result = filtered + [container]
    if "**" in pattern:
        skill_results = [_add(r) for r in sb.glob_info(pattern, "")]
        result = result + skill_results
    return result


async def _aglob_merge(base: list[Any], sb: Any, pattern: str) -> list[Any]:
    """Async equivalent of :func:`_glob_merge`."""
    filtered = [e for e in base if not e.get("path", "").startswith("/skills/")]
    container = await _amake_skills_dir_entry(sb)
    result = filtered + [container]
    if "**" in pattern:
        skill_results = [_add(r) for r in await sb.aglob_info(pattern, "")]
        result = result + skill_results
    return result


class _SkillsProxy:
    """Routes ``/skills/*`` operations to a ``FilesystemBackend`` scoped to *skills_dir*;
    delegates everything else to *base*.

    Path translation (stripping / re-adding the ``/skills`` prefix) is handled
    inline for every read method so that ``self._sb`` — a plain
    ``FilesystemBackend(root_dir=skills_dir)`` — sees only bare paths.
    All 6 write methods raise ``PermissionError`` for ``/skills/`` paths and
    delegate to *base* otherwise.
    Unknown attributes fall through ``__getattr__`` to *base*.
    """

    def __init__(self, base: Any, skills_backend: Any) -> None:
        self._base = base
        self._sb = skills_backend  # FilesystemBackend(root_dir=skills_dir, virtual_mode=True)

    # ---- read methods ----

    def ls_info(self, path: str) -> list[Any]:
        if path.startswith("/skills/") or path == _SKILLS_PREFIX:
            return [_add(r) for r in self._sb.ls_info(_strip(path))]
        if _is_root(path):
            entry = _make_skills_dir_entry(self._sb)
            return _ls_merge(self._base.ls_info(path), entry)
        return self._base.ls_info(path)

    async def als_info(self, path: str) -> list[Any]:
        if path.startswith("/skills/") or path == _SKILLS_PREFIX:
            return [_add(r) for r in await self._sb.als_info(_strip(path))]
        if _is_root(path):
            entry = await _amake_skills_dir_entry(self._sb)
            return _ls_merge(await self._base.als_info(path), entry)
        return await self._base.als_info(path)

    def download_files(self, paths: list[str]) -> list[Any]:
        skill = [p for p in paths if p.startswith("/skills/")]
        other = [p for p in paths if not p.startswith("/skills/")]
        r: dict[str, Any] = {}
        if skill:
            results = self._sb.download_files([_strip(p) for p in skill])
            r.update(zip(skill, [_fix_path(res, orig) for res, orig in zip(results, skill, strict=True)], strict=True))
        if other:
            r.update(zip(other, self._base.download_files(other)))
        return [r[p] for p in paths]

    async def adownload_files(self, paths: list[str]) -> list[Any]:
        skill = [p for p in paths if p.startswith("/skills/")]
        other = [p for p in paths if not p.startswith("/skills/")]
        r: dict[str, Any] = {}
        if skill:
            results = await self._sb.adownload_files([_strip(p) for p in skill])
            r.update(zip(skill, [_fix_path(res, orig) for res, orig in zip(results, skill, strict=True)], strict=True))
        if other:
            r.update(zip(other, await self._base.adownload_files(other)))
        return [r[p] for p in paths]

    def read(self, file_path: str, offset: int = 0, limit: int = 2000) -> str:
        if file_path.startswith("/skills/"):
            return self._sb.read(_strip(file_path), offset, limit)
        return self._base.read(file_path, offset, limit)

    async def aread(self, file_path: str, offset: int = 0, limit: int = 2000) -> str:
        if file_path.startswith("/skills/"):
            return await self._sb.aread(_strip(file_path), offset, limit)
        return await self._base.aread(file_path, offset, limit)

    def glob_info(self, pattern: str, path: str = "/") -> list[Any]:
        if path.startswith("/skills/") or path == _SKILLS_PREFIX or pattern.startswith("/skills/"):
            p = _strip(pattern) if pattern.startswith("/skills/") else pattern
            return [_add(r) for r in self._sb.glob_info(p, _strip(path))]
        if _is_root(path):
            return _glob_merge(self._base.glob_info(pattern, path), self._sb, pattern)
        return self._base.glob_info(pattern, path)

    async def aglob_info(self, pattern: str, path: str = "/") -> list[Any]:
        if path.startswith("/skills/") or path == _SKILLS_PREFIX or pattern.startswith("/skills/"):
            p = _strip(pattern) if pattern.startswith("/skills/") else pattern
            return [_add(r) for r in await self._sb.aglob_info(p, _strip(path))]
        if _is_root(path):
            return await _aglob_merge(await self._base.aglob_info(pattern, path), self._sb, pattern)
        return await self._base.aglob_info(pattern, path)

    def grep_raw(self, pattern: str, path: str | None = None, glob: str | None = None) -> Any:
        if path and path.startswith("/skills/"):
            results = self._sb.grep_raw(pattern, _strip(path), glob)
            return [_add(r) for r in results] if isinstance(results, list) else results
        return self._base.grep_raw(pattern, path, glob)

    async def agrep_raw(self, pattern: str, path: str | None = None, glob: str | None = None) -> Any:
        if path and path.startswith("/skills/"):
            results = await self._sb.agrep_raw(pattern, _strip(path), glob)
            return [_add(r) for r in results] if isinstance(results, list) else results
        return await self._base.agrep_raw(pattern, path, glob)

    # ---- write methods (blocked for /skills/ paths) ----

    def write(self, file_path: str, content: str) -> Any:
        if file_path.startswith("/skills/"):
            raise PermissionError(_SKILLS_WRITE_ERROR)
        return self._base.write(file_path, content)

    async def awrite(self, file_path: str, content: str) -> Any:
        if file_path.startswith("/skills/"):
            raise PermissionError(_SKILLS_WRITE_ERROR)
        return await self._base.awrite(file_path, content)

    def edit(self, file_path: str, old_string: str, new_string: str, replace_all: bool = False) -> Any:
        if file_path.startswith("/skills/"):
            raise PermissionError(_SKILLS_WRITE_ERROR)
        return self._base.edit(file_path, old_string, new_string, replace_all)

    async def aedit(self, file_path: str, old_string: str, new_string: str, replace_all: bool = False) -> Any:
        if file_path.startswith("/skills/"):
            raise PermissionError(_SKILLS_WRITE_ERROR)
        return await self._base.aedit(file_path, old_string, new_string, replace_all)

    def upload_files(self, files: list[tuple[str, bytes]]) -> Any:
        if any(path.startswith("/skills/") for path, _ in files):
            raise PermissionError(_SKILLS_WRITE_ERROR)
        return self._base.upload_files(files)

    async def aupload_files(self, files: list[tuple[str, bytes]]) -> Any:
        if any(path.startswith("/skills/") for path, _ in files):
            raise PermissionError(_SKILLS_WRITE_ERROR)
        return await self._base.aupload_files(files)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._base, name)


@functools.lru_cache(maxsize=1)
def _sandbox_proxy_class() -> type:
    """Return a _SkillsProxy subclass that passes SandboxBackendProtocol isinstance checks.

    Created lazily and cached — avoids importing deepagents at module load time.
    Only called when the base backend is already a SandboxBackendProtocol instance.
    """
    from deepagents.backends.protocol import SandboxBackendProtocol

    class _SandboxSkillsProxy(_SkillsProxy, SandboxBackendProtocol):  # type: ignore[misc]
        """_SkillsProxy that also satisfies SandboxBackendProtocol isinstance checks.

        Explicitly forwards execute/aexecute/id so the NotImplementedError stubs
        on SandboxBackendProtocol are shadowed by these delegating overrides.
        """

        @property
        def id(self) -> str:
            return self._base.id  # type: ignore[return-value]

        def execute(self, command: str, *, timeout: int | None = None) -> Any:
            return self._base.execute(command, timeout=timeout)

        async def aexecute(self, command: str, *, timeout: int | None = None) -> Any:
            return await self._base.aexecute(command, timeout=timeout)

    return _SandboxSkillsProxy


def build_skills_backend_factory(backend_factory: Any, skills_dir: Path) -> Any:
    """Return a backend factory that wraps *backend_factory* with :class:`_SkillsProxy`.

    The returned callable accepts a ``ToolRuntime`` and produces a
    :class:`_SkillsProxy` that routes ``/skills/*`` reads to a
    ``FilesystemBackend(root_dir=skills_dir)`` while delegating everything else
    to the original backend.

    When *backend_factory* is ``None``, ``StateBackend`` is used as the base.
    """
    from deepagents.backends import FilesystemBackend as _FSB
    from deepagents.backends import StateBackend as _SB

    _orig = backend_factory
    _skills_fsb = _FSB(root_dir=str(skills_dir), virtual_mode=True)

    def _factory(rt: Any) -> _SkillsProxy:
        from deepagents.backends.composite import CompositeBackend
        from deepagents.backends.protocol import SandboxBackendProtocol

        base: Any = _SB(rt) if _orig is None else _orig(rt)
        is_sandbox = isinstance(base, SandboxBackendProtocol) or (
            isinstance(base, CompositeBackend)
            and isinstance(base.default, SandboxBackendProtocol)
        )
        cls = _sandbox_proxy_class() if is_sandbox else _SkillsProxy
        return cls(base, _skills_fsb)

    return _factory
