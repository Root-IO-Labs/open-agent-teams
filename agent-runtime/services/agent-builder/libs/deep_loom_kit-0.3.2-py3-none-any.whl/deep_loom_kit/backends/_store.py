"""Service-level store builder (Postgres, InMemory)."""

from __future__ import annotations

import os
from typing import Any


def _build_postgres_store(cfg: Any) -> tuple[Any, Any]:
    """Build a PostgresStore from a :class:`PostgresStoreConfig`."""
    try:
        from langgraph.store.postgres import PostgresStore
    except ImportError as exc:
        raise ImportError(
            "PostgresStore is provided by the 'langgraph' package. "
            "Ensure langgraph>=0.2.0 is installed: pip install deep-loom-kit"
        ) from exc
    conn_str = os.environ.get(cfg.connection_string_env)
    if not conn_str:
        raise RuntimeError(
            f"PostgresStore: environment variable '{cfg.connection_string_env}' is not set"
        )
    store_ctx = PostgresStore.from_conn_string(
        conn_str,
        pool_size=cfg.pool_size,
        max_overflow=cfg.max_overflow,
    )
    store = store_ctx.__enter__()
    store.setup()
    return store, store_ctx


def build_store(cfg: Any) -> tuple[Any, Any]:
    """Build a ``(store, store_ctx)`` pair from a :class:`ServiceStoreConfig`.

    ``store_ctx`` is the context manager that must be ``__exit__``'d on shutdown.
    Returns ``(store, None)`` if no lifecycle management is needed.
    """
    from ..schema import PostgresStoreConfig

    if isinstance(cfg, PostgresStoreConfig):
        return _build_postgres_store(cfg)
    raise ValueError(f"Unknown store config type: {type(cfg).__name__}")
