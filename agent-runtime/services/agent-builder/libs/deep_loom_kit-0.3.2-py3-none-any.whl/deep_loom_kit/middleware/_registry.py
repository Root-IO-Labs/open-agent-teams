"""Middleware registry for deep-loom-kit."""

from __future__ import annotations

import importlib.util
import inspect
import warnings
from pathlib import Path
from typing import Any

# Hook method names defined on AgentMiddleware (sync + async variants).
_HOOK_METHODS = frozenset({
    "before_agent", "abefore_agent",
    "before_model", "abefore_model",
    "after_model", "aafter_model",
    "after_agent", "aafter_agent",
    "wrap_model_call", "awrap_model_call",
    "wrap_tool_call", "awrap_tool_call",
})

_MIDDLEWARE_REGISTRY: dict[str, Any] = {}


def _is_middleware_instance(obj: object) -> bool:
    """Duck-type check: AgentMiddleware class instance (not the class itself).

    Matches both decorator-based middleware (which the langchain decorators
    wrap into AgentMiddleware subclass instances) and class-based middleware
    (explicit AgentMiddleware subclasses).  Plain callables and class objects
    are excluded.
    """
    if isinstance(obj, type):
        return False
    return any(
        hasattr(obj, m) and callable(getattr(obj, m))
        for m in _HOOK_METHODS
    )


def register_middleware(name: str, middleware: Any) -> None:
    """Register a middleware instance under *name*.

    Args:
        name: Key used to reference this middleware in YAML ``middleware:`` lists.
        middleware: An ``AgentMiddleware`` instance (class-based or decorator-based).
    """
    _MIDDLEWARE_REGISTRY[name] = middleware


def resolve_middleware(names: list[str]) -> list[Any]:
    """Resolve a list of names to registered middleware instances.

    Args:
        names: Names previously registered with :func:`register_middleware`.

    Returns:
        Ordered list of middleware instances.

    Raises:
        ValueError: If any name is not in the registry.
    """
    result: list[Any] = []
    missing: list[str] = []
    for name in names:
        if name in _MIDDLEWARE_REGISTRY:
            result.append(_MIDDLEWARE_REGISTRY[name])
        else:
            missing.append(name)
    if missing:
        raise ValueError(f"Unregistered middleware: {', '.join(missing)}")
    return result


def auto_register_middleware(middleware_dir: Path, required: set[str] | None = None) -> list[str]:
    """Import every ``*.py`` in *middleware_dir* and register ``AgentMiddleware``
    instances found at module level.

    Registration rules:
    - Any non-private ``AgentMiddleware`` instance is registered (decorator-based
      or class-based).  Imported plain functions/decorators are not instances and
      are therefore skipped automatically.
    - Only non-private names (no leading ``_``) are registered.
    - Already-registered names are skipped.
    - Import errors emit a warning and continue to the next file.

    Args:
        middleware_dir: Directory to scan.  Returns ``[]`` if absent.
        required: Names to register.  Only middleware whose name appears in this
            set are registered.  When ``None`` or empty nothing is registered.

    Returns:
        List of newly registered middleware names.
    """
    middleware_dir = Path(middleware_dir)
    if not middleware_dir.is_dir():
        return []

    registered: list[str] = []
    for py_file in sorted(middleware_dir.glob("*.py")):
        spec = importlib.util.spec_from_file_location(py_file.stem, py_file)
        if spec is None or spec.loader is None:
            continue
        module = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(module)  # type: ignore[union-attr]
        except Exception:
            warnings.warn(
                f"auto_register_middleware: could not import {py_file}"
            )
            continue

        for obj_name, obj in inspect.getmembers(module):
            if obj_name.startswith("_"):
                continue
            if obj_name in _MIDDLEWARE_REGISTRY:
                continue
            if required and _is_middleware_instance(obj) and obj_name in required:
                register_middleware(obj_name, obj)
                registered.append(obj_name)

    return registered
