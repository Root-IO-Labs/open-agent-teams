"""Middleware registry and built-in middleware implementations."""

from ._registry import (
    _MIDDLEWARE_REGISTRY,          # private — re-exported for tests
    _is_middleware_instance,       # private — re-exported for tests
    _HOOK_METHODS,                 # private — re-exported for tests
    auto_register_middleware,
    register_middleware,
    resolve_middleware,
)
from ._datetime import DatetimeMiddleware, _datetime_line

__all__ = [
    "auto_register_middleware",
    "register_middleware",
    "resolve_middleware",
    "DatetimeMiddleware",
]
