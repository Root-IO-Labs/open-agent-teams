"""Built-in middleware that injects the current date and time into every model call."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import TYPE_CHECKING

from langchain.agents.middleware.types import AgentMiddleware

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from langchain.agents.middleware.types import ModelRequest, ModelResponse

_DATETIME_TEMPLATE = "\n\n---\nCurrent date and time: {dt} UTC\n"


def _datetime_line() -> str:
    now = datetime.now(timezone.utc)
    return _DATETIME_TEMPLATE.format(
        dt=f"{now.strftime('%A, %B')} {now.day}, {now.year} at {now.strftime('%H:%M:%S')}"
    )


class DatetimeMiddleware(AgentMiddleware):
    """Injects the current UTC date and time into the system message on every model call.

    Enabled by default for all agents (``datetime_awareness: true`` in YAML).
    Disable with ``datetime_awareness: false``.
    """

    def _inject(self, request: ModelRequest) -> ModelRequest:  # type: ignore[type-arg]
        from deepagents.middleware._utils import append_to_system_message
        new_system = append_to_system_message(request.system_message, _datetime_line())
        return request.override(system_message=new_system)

    def wrap_model_call(
        self,
        request: ModelRequest,  # type: ignore[type-arg]
        handler: Callable[[ModelRequest], ModelResponse],  # type: ignore[type-arg]
    ) -> ModelResponse:  # type: ignore[type-arg]
        return handler(self._inject(request))

    async def awrap_model_call(
        self,
        request: ModelRequest,  # type: ignore[type-arg]
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],  # type: ignore[type-arg]
    ) -> ModelResponse:  # type: ignore[type-arg]
        return await handler(self._inject(request))
